# OUTFITLY — Premium Gen Z Fashion App

A complete, production-quality e-commerce React app. Built with Vite + TypeScript + TailwindCSS + Zustand.

---

## 🚀 Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start dev server
npm run dev
# → Open http://localhost:5173
```

---

## 🔐 Demo Accounts

| Role   | Email                   | Password     |
|--------|-------------------------|--------------|
| User 1 | aryan@demo.com          | Aryan@123    |
| User 2 | priya@demo.com          | Priya@123    |
| Admin  | admin@outfitly.demo     | Admin@1234   |

> Guest users can browse & add to cart/wishlist, but must login to checkout.

---

## 📧 Order Email Notifications (Optional - Free)

To receive real order email notifications:

1. Go to **https://formspree.io** → sign up (free)
2. Create a new form → copy your Form ID (e.g. `xabc1234`)
3. Create `.env.local` in the project root:
   ```
   VITE_FORMSPREE_ID=xabc1234
   ```
4. Restart dev server

Without this, orders are logged to the browser console and saved in the Admin panel.

---

## 🗂 Project Structure

```
src/
├── App.tsx                  # Router + lazy-loaded routes
├── main.tsx                 # App entry + theme init
├── index.css                # Tailwind + custom utilities
├── types/index.ts           # All TypeScript interfaces
├── data/
│   ├── items.ts             # 30 items (all ≤₹500)
│   └── combos.ts            # 18 outfit combos
├── store/
│   ├── authStore.ts         # Auth (Zustand + persist)
│   ├── cartStore.ts         # Cart with bundles
│   ├── wishlistStore.ts     # Wishlist
│   ├── themeStore.ts        # Dark/light mode
│   └── orderStore.ts        # Orders
├── utils/
│   ├── formatters.ts        # Price, date, ID utils
│   ├── export.ts            # JSON/CSV export
│   └── notify.ts            # Mock + Formspree email
├── components/
│   ├── layout/              # Header, BottomNav, Layout
│   ├── ui/                  # Modal, Skeleton, QuantityStepper
│   ├── cards/               # OutfitCard, ItemCard
│   └── ItemDetailModal.tsx
├── pages/                   # All 12 pages
├── routes/                  # ProtectedRoute, AdminRoute
└── tests/                   # Vitest unit tests
tests/
└── e2e/checkout.spec.ts     # Playwright e2e
```

---

## ✅ All Pages & Features

| Page               | Route             | Status |
|--------------------|-------------------|--------|
| Login / Sign Up    | /auth             | ✅     |
| Homepage           | /                 | ✅     |
| Search + Filters   | /search           | ✅     |
| Outfit Combo Detail| /outfit/:id       | ✅     |
| Single Item Detail | /item/:id         | ✅     |
| Cart               | /cart             | ✅     |
| Checkout           | /checkout         | ✅     |
| Order Success      | /success/:orderId | ✅     |
| Wishlist           | /wishlist         | ✅     |
| My Orders          | /orders           | ✅     |
| Admin Dashboard    | /admin            | ✅     |
| 404                | /*                | ✅     |

---

## 🧪 Testing

```bash
# Unit tests (Vitest)
npm run test

# E2E tests (Playwright) - needs dev server running
npx playwright install
npm run test:e2e
```

---

## 🏗 Build for Production

```bash
npm run build
npm run preview
```

---

## 🎨 Design Tokens

- **Accent color**: `#BBFF00` (Electric Lime)
- **Dark bg**: `#0C0C0B`
- **Dark surface**: `#1A1A18`
- **Font display**: Cormorant Garamond
- **Font UI**: Syne
- **Default theme**: Dark (persisted per user)

---

## ⚙️ Key Business Rules (enforced in code)

- Every item price ≤ ₹500 (runtime assertion in dev mode)
- Combo discount 8–15% (stable per dataset)
- Delivery fee: ₹0. Taxes: ₹0
- Guest cannot checkout — must login
- Admin-only route `/admin` (redirect non-admins)

---

## 📱 Responsive Breakpoints

Tested on: 320px, 375px, 414px, 768px, 1024px, 1440px

- Mobile: Bottom navigation, horizontal scroll carousels, bottom sheet filters
- Desktop: Top navigation, sidebar filters, multi-column grids

---

## 📦 Getting Order Data

All orders are:
1. **Admin Panel** `/admin` — full table with export buttons
2. **Browser Console** — full order JSON on every placement
3. **LocalStorage** — key `outfitly-orders`
4. **Download** — JSON and CSV from Success page and Admin panel
5. **Email** (optional) — via Formspree (see setup above)
