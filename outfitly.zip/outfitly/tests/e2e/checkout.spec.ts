import { test, expect } from '@playwright/test';

test.describe('OUTFITLY E2E - Happy Path', () => {
  test.beforeEach(async ({ page }) => {
    // Clear localStorage between tests
    await page.goto('/');
    await page.evaluate(() => localStorage.clear());
  });

  test('Auth page shows login/signup and redirects to home after login', async ({ page }) => {
    await page.goto('/auth');
    await expect(page.getByText('OUTFITLY')).toBeVisible();

    // Fill login form
    await page.fill('input[type="email"]', 'aryan@demo.com');
    await page.fill('input[type="password"]', 'Aryan@123');
    await page.click('button[type="submit"]');

    // Should redirect to homepage
    await expect(page).toHaveURL('/');
  });

  test('Guest can browse homepage and search', async ({ page }) => {
    await page.goto('/');
    await page.click('text=Continue as Guest');
    await expect(page).toHaveURL('/');

    // Navigate to search
    await page.goto('/search');
    await expect(page.locator('input[placeholder*="Search"]').first()).toBeVisible();
  });

  test('Add outfit combo to cart', async ({ page }) => {
    await page.goto('/auth');
    await page.fill('input[type="email"]', 'aryan@demo.com');
    await page.fill('input[type="password"]', 'Aryan@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('/');

    // Go to search and view first combo
    await page.goto('/search?tab=combos');
    const firstCombo = page.locator('[role="article"]').first();
    await firstCombo.click();
    await page.waitForURL(/\/outfit\/.+/);

    // Click "Buy Full Outfit"
    await page.click('button:has-text("Buy Full Outfit")');
    await page.waitForURL('/cart');

    // Cart should have items
    await expect(page.locator('text=Your Cart')).toBeVisible();
  });

  test('Checkout flow creates order and shows success', async ({ page }) => {
    // Login
    await page.goto('/auth');
    await page.fill('input[type="email"]', 'aryan@demo.com');
    await page.fill('input[type="password"]', 'Aryan@123');
    await page.click('button[type="submit"]');
    await page.waitForURL('/');

    // Add single item to cart via search
    await page.goto('/search?tab=singles');
    const firstItem = page.locator('[role="article"]').first();
    await firstItem.click();
    await page.waitForURL(/\/item\/.+/);

    // Try to add to cart (select size if needed)
    const sizeButtons = page.locator('button').filter({ hasText: /^(XS|S|M|L|XL|One Size|6|7|8)$/ });
    if (await sizeButtons.count() > 0) {
      await sizeButtons.first().click();
    }
    await page.click('button:has-text("Add to Cart")');
    await page.goto('/cart');

    // Click checkout
    await page.click('button:has-text("Checkout")');
    await page.waitForURL('/checkout');

    // Fill address form
    await page.fill('input[placeholder="As on ID / door"]', 'Aryan Sharma');
    await page.fill('input[placeholder="10-digit mobile"]', '9876543210');
    await page.fill('input[placeholder="6-digit pincode"]', '400001');
    await page.fill('input[placeholder="Flat no., Street, Area"]', '12, Main Street, Bandra');
    await page.fill('input[placeholder="Mumbai"]', 'Mumbai');
    await page.fill('input[placeholder="Maharashtra"]', 'Maharashtra');

    // Place order
    await page.click('button:has-text("Place Order")');
    await page.waitForURL(/\/success\/.+/, { timeout: 10000 });

    // Verify success page
    await expect(page.locator('text=Order Placed')).toBeVisible();
    await expect(page.locator('text=Download JSON')).toBeVisible();
  });

  test('Admin login accesses admin panel', async ({ page }) => {
    await page.goto('/auth');
    await page.fill('input[type="email"]', 'admin@outfitly.demo');
    await page.fill('input[type="password"]', 'Admin@1234');
    await page.click('button[type="submit"]');
    await page.waitForURL('/');

    await page.goto('/admin');
    await expect(page.locator('text=Orders Dashboard')).toBeVisible();
  });

  test('Wishlist add and remove', async ({ page }) => {
    await page.goto('/');

    // Click wishlist heart on any card
    await page.goto('/search?tab=singles');
    const heartBtn = page.locator('button[aria-label*="wishlist"]').first();
    await heartBtn.click();

    await page.goto('/wishlist');
    const savedItems = page.locator('[role="article"], .card').first();
    await expect(savedItems).toBeVisible();
  });

  test('Dark/light mode toggle', async ({ page }) => {
    await page.goto('/');
    const htmlEl = page.locator('html');
    await expect(htmlEl).toHaveClass(/dark/);

    // Click theme toggle
    await page.click('button[aria-label*="light mode"], button[aria-label*="dark mode"]');
    // Theme should have changed
  });
});
