import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const AdminRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuthStore();

  if (!user) {
    toast.error('Admin access required', { id: 'admin-required' });
    return <Navigate to="/auth" replace />;
  }

  if (!user.isAdmin) {
    toast.error('You are not authorized to view this page', { id: 'admin-forbidden' });
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
};

export default AdminRoute;
