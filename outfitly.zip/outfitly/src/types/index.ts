export type Gender = 'boys' | 'girls' | 'unisex';
export type Category = 'top' | 'bottom' | 'shoes' | 'accessory';
export type StyleTag = 'streetwear' | 'minimal' | 'party' | 'casual' | 'y2k' | 'preppy' | 'athleisure';
export type PaymentMethod = 'upi' | 'card' | 'cod';
export type OrderStatus = 'placed' | 'confirmed' | 'shipped' | 'delivered';

export interface Item {
  id: string;
  name: string;
  category: Category;
  gender: Gender;
  styleTags: StyleTag[];
  price: number; // MUST be <= 500
  sizes: string[];
  colors: string[];
  imageUrl: string;
  altText: string;
  isNew: boolean;
  rating: number;
  trendingScore: number;
  description: string;
}

export interface OutfitCombo {
  id: string;
  title: string;
  description: string;
  items: Item[];
  heroImageUrl: string;
  gender: Gender;
  tags: string[];
  trendingScore: number;
  discountPercent: number; // 8–15
  totalBeforeDiscount: number;
  totalAfterDiscount: number;
}

export interface CartItem {
  item: Item;
  quantity: number;
  selectedSize: string;
  selectedColor: string;
}

export interface CartBundle {
  combo: OutfitCombo;
  selectedSizes: Record<string, string>; // itemId → size
  quantity: number;
}

export interface User {
  id: string;
  name: string;
  email: string;
  isAdmin: boolean;
}

export interface Address {
  fullName: string;
  phone: string;
  line1: string;
  line2?: string;
  city: string;
  state: string;
  pincode: string;
}

export interface Order {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  items: CartItem[];
  bundles: CartBundle[];
  subtotal: number;
  discount: number;
  total: number;
  address: Address;
  paymentMethod: PaymentMethod;
  status: OrderStatus;
  createdAt: string;
}

export interface WishlistItem {
  item: Item;
  addedAt: string;
}
