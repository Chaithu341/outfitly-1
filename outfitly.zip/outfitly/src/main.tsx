import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Apply persisted theme before first render to avoid flash
try {
  const savedTheme = localStorage.getItem('outfitly-theme');
  const isDark = savedTheme ? JSON.parse(savedTheme)?.state?.isDark !== false : true;
  document.documentElement.classList.toggle('dark', isDark);
} catch {
  document.documentElement.classList.add('dark');
}

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
