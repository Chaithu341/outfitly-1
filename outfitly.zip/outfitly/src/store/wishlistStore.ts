import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { WishlistItem, Item } from '../types';

interface WishlistState {
  items: WishlistItem[];
  addItem: (item: Item) => void;
  removeItem: (itemId: string) => void;
  toggleItem: (item: Item) => void;
  isWishlisted: (itemId: string) => boolean;
  clearWishlist: () => void;
}

export const useWishlistStore = create<WishlistState>()(
  persist(
    (set, get) => ({
      items: [],

      addItem(item) {
        if (get().isWishlisted(item.id)) return;
        set((state) => ({
          items: [...state.items, { item, addedAt: new Date().toISOString() }],
        }));
      },

      removeItem(itemId) {
        set((state) => ({
          items: state.items.filter((wi) => wi.item.id !== itemId),
        }));
      },

      toggleItem(item) {
        if (get().isWishlisted(item.id)) {
          get().removeItem(item.id);
        } else {
          get().addItem(item);
        }
      },

      isWishlisted(itemId) {
        return get().items.some((wi) => wi.item.id === itemId);
      },

      clearWishlist() {
        set({ items: [] });
      },
    }),
    {
      name: 'outfitly-wishlist',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
