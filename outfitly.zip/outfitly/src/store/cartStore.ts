import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { CartItem, CartBundle, Item, OutfitCombo } from '../types';

interface CartState {
  items: CartItem[];
  bundles: CartBundle[];
  subtotal: number;
  discount: number;
  total: number;
  itemCount: number;
  addItem: (item: Item, size: string, color: string, qty?: number) => void;
  removeItem: (itemId: string, size: string) => void;
  updateItemQty: (itemId: string, size: string, qty: number) => void;
  addBundle: (combo: OutfitCombo, selectedSizes: Record<string, string>) => void;
  removeBundle: (comboId: string) => void;
  updateBundleQty: (comboId: string, qty: number) => void;
  clearCart: () => void;
}

const computeDerived = (items: CartItem[], bundles: CartBundle[]) => {
  const itemsTotal = items.reduce((s, ci) => s + ci.item.price * ci.quantity, 0);
  const bundlesBeforeDiscount = bundles.reduce((s, cb) => s + cb.combo.totalBeforeDiscount * cb.quantity, 0);
  const bundlesAfterDiscount = bundles.reduce((s, cb) => s + cb.combo.totalAfterDiscount * cb.quantity, 0);
  return {
    subtotal: itemsTotal + bundlesBeforeDiscount,
    discount: bundlesBeforeDiscount - bundlesAfterDiscount,
    total: itemsTotal + bundlesAfterDiscount,
    itemCount: items.reduce((s, ci) => s + ci.quantity, 0) + bundles.reduce((s, cb) => s + cb.quantity, 0),
  };
};

export const useCartStore = create<CartState>()(
  persist(
    (set, get) => ({
      items: [],
      bundles: [],
      subtotal: 0,
      discount: 0,
      total: 0,
      itemCount: 0,

      addItem(item, size, color, qty = 1) {
        set((state) => {
          const existing = state.items.find((ci) => ci.item.id === item.id && ci.selectedSize === size);
          const newItems = existing
            ? state.items.map((ci) => ci.item.id === item.id && ci.selectedSize === size ? { ...ci, quantity: ci.quantity + qty } : ci)
            : [...state.items, { item, quantity: qty, selectedSize: size, selectedColor: color }];
          return { items: newItems, ...computeDerived(newItems, state.bundles) };
        });
      },

      removeItem(itemId, size) {
        set((state) => {
          const newItems = state.items.filter((ci) => !(ci.item.id === itemId && ci.selectedSize === size));
          return { items: newItems, ...computeDerived(newItems, state.bundles) };
        });
      },

      updateItemQty(itemId, size, qty) {
        if (qty <= 0) { get().removeItem(itemId, size); return; }
        set((state) => {
          const newItems = state.items.map((ci) => ci.item.id === itemId && ci.selectedSize === size ? { ...ci, quantity: qty } : ci);
          return { items: newItems, ...computeDerived(newItems, state.bundles) };
        });
      },

      addBundle(combo, selectedSizes) {
        set((state) => {
          const existing = state.bundles.find((b) => b.combo.id === combo.id);
          const newBundles = existing
            ? state.bundles.map((b) => b.combo.id === combo.id ? { ...b, quantity: b.quantity + 1 } : b)
            : [...state.bundles, { combo, selectedSizes, quantity: 1 }];
          return { bundles: newBundles, ...computeDerived(state.items, newBundles) };
        });
      },

      removeBundle(comboId) {
        set((state) => {
          const newBundles = state.bundles.filter((b) => b.combo.id !== comboId);
          return { bundles: newBundles, ...computeDerived(state.items, newBundles) };
        });
      },

      updateBundleQty(comboId, qty) {
        if (qty <= 0) { get().removeBundle(comboId); return; }
        set((state) => {
          const newBundles = state.bundles.map((b) => b.combo.id === comboId ? { ...b, quantity: qty } : b);
          return { bundles: newBundles, ...computeDerived(state.items, newBundles) };
        });
      },

      clearCart() {
        set({ items: [], bundles: [], subtotal: 0, discount: 0, total: 0, itemCount: 0 });
      },
    }),
    {
      name: 'outfitly-cart',
      storage: createJSONStorage(() => localStorage),
      onRehydrateStorage: () => (state) => {
        if (state) {
          const derived = computeDerived(state.items, state.bundles);
          Object.assign(state, derived);
        }
      },
    }
  )
);
