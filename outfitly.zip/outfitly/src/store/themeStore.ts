import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

interface ThemeState {
  isDark: boolean;
  toggleTheme: () => void;
  setTheme: (isDark: boolean) => void;
}

const applyTheme = (isDark: boolean) => {
  const root = document.documentElement;
  if (isDark) {
    root.classList.add('dark');
  } else {
    root.classList.remove('dark');
  }
};

export const useThemeStore = create<ThemeState>()(
  persist(
    (set) => ({
      isDark: true, // default dark mode

      toggleTheme() {
        set((state) => {
          applyTheme(!state.isDark);
          return { isDark: !state.isDark };
        });
      },

      setTheme(isDark) {
        applyTheme(isDark);
        set({ isDark });
      },
    }),
    {
      name: 'outfitly-theme',
      storage: createJSONStorage(() => localStorage),
      onRehydrateStorage: () => (state) => {
        if (state) applyTheme(state.isDark);
      },
    }
  )
);
