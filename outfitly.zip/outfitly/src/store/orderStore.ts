import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { Order } from '../types';

interface OrderState {
  orders: Order[];
  addOrder: (order: Order) => void;
  getUserOrders: (userId: string) => Order[];
  getAllOrders: () => Order[];
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
}

export const useOrderStore = create<OrderState>()(
  persist(
    (set, get) => ({
      orders: [],

      addOrder(order) {
        set((state) => ({ orders: [order, ...state.orders] }));
      },

      getUserOrders(userId) {
        return get().orders.filter((o) => o.userId === userId);
      },

      getAllOrders() {
        return get().orders;
      },

      updateOrderStatus(orderId, status) {
        set((state) => ({
          orders: state.orders.map((o) => (o.id === orderId ? { ...o, status } : o)),
        }));
      },
    }),
    {
      name: 'outfitly-orders',
      storage: createJSONStorage(() => localStorage),
    }
  )
);
