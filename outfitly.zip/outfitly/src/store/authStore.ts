import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import type { User } from '../types';

interface StoredUser extends User {
  passwordHash: string;
}

// Dummy user database stored in-memory (persisted alongside registered users)
const SEED_USERS: StoredUser[] = [
  {
    id: 'user-001',
    name: 'Aryan Sharma',
    email: 'aryan@demo.com',
    isAdmin: false,
    passwordHash: 'Aryan@123',
  },
  {
    id: 'user-002',
    name: 'Priya Patel',
    email: 'priya@demo.com',
    isAdmin: false,
    passwordHash: 'Priya@123',
  },
  {
    id: 'admin-001',
    name: 'Admin',
    email: 'admin@outfitly.demo',
    isAdmin: true,
    passwordHash: 'Admin@1234',
  },
];

interface AuthState {
  user: User | null;
  registeredUsers: StoredUser[];
  isGuest: boolean;
  login: (email: string, password: string) => { success: boolean; message: string };
  signup: (
    name: string,
    email: string,
    password: string
  ) => { success: boolean; message: string };
  logout: () => void;
  continueAsGuest: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      registeredUsers: SEED_USERS,
      isGuest: false,

      login: (email, password) => {
        const allUsers = get().registeredUsers;
        const found = allUsers.find(
          (u) => u.email.toLowerCase() === email.toLowerCase() && u.passwordHash === password
        );
        if (!found) {
          return { success: false, message: 'Invalid email or password.' };
        }
        const { passwordHash: _pw, ...user } = found;
        set({ user, isGuest: false });
        return { success: true, message: `Welcome back, ${user.name}!` };
      },

      signup: (name, email, password) => {
        const allUsers = get().registeredUsers;
        const exists = allUsers.some((u) => u.email.toLowerCase() === email.toLowerCase());
        if (exists) {
          return { success: false, message: 'An account with this email already exists.' };
        }
        const newUser: StoredUser = {
          id: `user-${Date.now()}`,
          name,
          email: email.toLowerCase(),
          isAdmin: false,
          passwordHash: password,
        };
        set((state) => ({
          registeredUsers: [...state.registeredUsers, newUser],
          user: { id: newUser.id, name: newUser.name, email: newUser.email, isAdmin: false },
          isGuest: false,
        }));
        return { success: true, message: `Welcome to OUTFITLY, ${name}!` };
      },

      logout: () => set({ user: null, isGuest: false }),

      continueAsGuest: () => set({ user: null, isGuest: true }),
    }),
    {
      name: 'outfitly-auth',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        user: state.user,
        isGuest: state.isGuest,
        registeredUsers: state.registeredUsers,
      }),
    }
  )
);
