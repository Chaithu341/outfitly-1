import { describe, it, expect } from 'vitest';
import { combos } from '../data/combos';
import { items } from '../data/items';

describe('Combo discount calculations', () => {
  it('all items have price <= ₹500', () => {
    items.forEach((item) => {
      expect(item.price).toBeLessThanOrEqual(500);
    });
  });

  it('all combos have totalBeforeDiscount = sum of item prices', () => {
    combos.forEach((combo) => {
      const expectedTotal = combo.items.reduce((s, item) => s + item.price, 0);
      expect(combo.totalBeforeDiscount).toBe(expectedTotal);
    });
  });

  it('all combos have totalAfterDiscount = round(before × (1 - discount%))', () => {
    combos.forEach((combo) => {
      const expected = Math.round(
        combo.totalBeforeDiscount * (1 - combo.discountPercent / 100)
      );
      expect(combo.totalAfterDiscount).toBe(expected);
    });
  });

  it('all combo discounts are between 8% and 15%', () => {
    combos.forEach((combo) => {
      expect(combo.discountPercent).toBeGreaterThanOrEqual(8);
      expect(combo.discountPercent).toBeLessThanOrEqual(15);
    });
  });

  it('totalAfterDiscount is always less than totalBeforeDiscount', () => {
    combos.forEach((combo) => {
      expect(combo.totalAfterDiscount).toBeLessThan(combo.totalBeforeDiscount);
    });
  });

  it('18 combos exist', () => {
    expect(combos).toHaveLength(18);
  });

  it('30 items exist', () => {
    expect(items).toHaveLength(30);
  });

  it('each combo has at least 2 items', () => {
    combos.forEach((combo) => {
      expect(combo.items.length).toBeGreaterThanOrEqual(2);
    });
  });

  it('savings amount is always positive', () => {
    combos.forEach((combo) => {
      const savings = combo.totalBeforeDiscount - combo.totalAfterDiscount;
      expect(savings).toBeGreaterThan(0);
    });
  });
});
