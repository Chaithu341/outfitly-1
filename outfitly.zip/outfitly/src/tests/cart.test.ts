import { describe, it, expect, beforeEach } from 'vitest';
import { useCartStore } from '../store/cartStore';
import { items } from '../data/items';
import { combos } from '../data/combos';

const sampleItem = items[0]; // Oversized Drop-Shoulder Tee — ₹299
const sampleItem2 = items[5]; // Olive Cargo Pants — ₹499
const sampleCombo = combos[0]; // Urban Edge combo

describe('CartStore — individual items', () => {
  beforeEach(() => {
    useCartStore.setState({ items: [], bundles: [] });
  });

  it('adds an item to cart', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    const state = useCartStore.getState();
    expect(state.items).toHaveLength(1);
    expect(state.items[0].item.id).toBe(sampleItem.id);
    expect(state.items[0].selectedSize).toBe('M');
  });

  it('increments quantity for same item+size', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.addItem(sampleItem, 'M', 'White');
    const state = useCartStore.getState();
    expect(state.items).toHaveLength(1);
    expect(state.items[0].quantity).toBe(2);
  });

  it('treats same item with different sizes as separate cart entries', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.addItem(sampleItem, 'L', 'White');
    expect(useCartStore.getState().items).toHaveLength(2);
  });

  it('removes an item from cart', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.removeItem(sampleItem.id, 'M');
    expect(useCartStore.getState().items).toHaveLength(0);
  });

  it('updates item quantity', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.updateItemQty(sampleItem.id, 'M', 5);
    expect(useCartStore.getState().items[0].quantity).toBe(5);
  });

  it('removes item when quantity set to 0', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.updateItemQty(sampleItem.id, 'M', 0);
    expect(useCartStore.getState().items).toHaveLength(0);
  });

  it('calculates subtotal correctly for items', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White', 2); // ₹299 × 2 = ₹598
    store.addItem(sampleItem2, '32', 'Olive', 1); // ₹499
    const state = useCartStore.getState();
    expect(state.subtotal).toBe(2 * sampleItem.price + sampleItem2.price);
  });

  it('clears cart', () => {
    const store = useCartStore.getState();
    store.addItem(sampleItem, 'M', 'White');
    store.addItem(sampleItem2, '32', 'Olive');
    store.clearCart();
    const state = useCartStore.getState();
    expect(state.items).toHaveLength(0);
    expect(state.bundles).toHaveLength(0);
  });
});

describe('CartStore — bundles', () => {
  beforeEach(() => {
    useCartStore.setState({ items: [], bundles: [] });
  });

  it('adds a bundle to cart', () => {
    const store = useCartStore.getState();
    store.addBundle(sampleCombo, {});
    expect(useCartStore.getState().bundles).toHaveLength(1);
  });

  it('increments bundle quantity on duplicate add', () => {
    const store = useCartStore.getState();
    store.addBundle(sampleCombo, {});
    store.addBundle(sampleCombo, {});
    expect(useCartStore.getState().bundles[0].quantity).toBe(2);
  });

  it('removes a bundle', () => {
    const store = useCartStore.getState();
    store.addBundle(sampleCombo, {});
    store.removeBundle(sampleCombo.id);
    expect(useCartStore.getState().bundles).toHaveLength(0);
  });

  it('calculates discount for bundles correctly', () => {
    const store = useCartStore.getState();
    store.addBundle(sampleCombo, {});
    const state = useCartStore.getState();
    const expectedDiscount = sampleCombo.totalBeforeDiscount - sampleCombo.totalAfterDiscount;
    expect(state.discount).toBe(expectedDiscount);
  });

  it('total = subtotal - discount', () => {
    const store = useCartStore.getState();
    store.addBundle(sampleCombo, {});
    store.addItem(sampleItem, 'M', 'White', 1);
    const state = useCartStore.getState();
    expect(state.total).toBe(state.subtotal - state.discount);
  });
});
