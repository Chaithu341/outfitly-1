import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useWishlistStore } from '../../store/wishlistStore';
import { formatPrice } from '../../utils/formatters';
import type { OutfitCombo } from '../../types';
import ImageWithFallback from '../ui/ImageWithFallback';

interface Props {
  combo: OutfitCombo;
  compact?: boolean;
}

const HeartIcon: React.FC<{ filled: boolean }> = ({ filled }) => (
  <svg
    className={`w-5 h-5 transition-colors ${filled ? 'fill-red-500 text-red-500' : 'fill-none text-white'}`}
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth={2}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"
    />
  </svg>
);

const OutfitCard: React.FC<Props> = ({ combo, compact = false }) => {
  const navigate = useNavigate();
  const { isWishlisted, toggleItem } = useWishlistStore();
  const mainItem = combo.items[0];
  const wishlisted = isWishlisted(mainItem.id);
  const savingsAmount = combo.totalBeforeDiscount - combo.totalAfterDiscount;

  return (
    <motion.div
      whileHover={{ y: -4 }}
      transition={{ duration: 0.2, ease: 'easeOut' }}
      className="card overflow-hidden cursor-pointer group"
      onClick={() => navigate(`/outfit/${combo.id}`)}
      role="article"
      aria-label={combo.title}
    >
      {/* Image */}
      <div className="relative overflow-hidden aspect-[3/4]">
        <ImageWithFallback
          src={combo.heroImageUrl}
          alt={combo.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Overlay badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5">
          {combo.tags.includes('trending') && (
            <span className="bg-accent text-accent-fg text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              Trending
            </span>
          )}
          {combo.tags.includes('new') && (
            <span className="bg-white text-neutral-900 text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              New
            </span>
          )}
          {combo.tags.includes('bestseller') && (
            <span className="bg-neutral-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              Bestseller
            </span>
          )}
        </div>

        {/* Discount badge */}
        <div className="absolute top-3 right-3">
          <span className="bg-accent text-accent-fg text-xs font-bold px-2 py-1 rounded-full">
            {combo.discountPercent}% off
          </span>
        </div>

        {/* Wishlist button */}
        <button
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          onClick={(e) => {
            e.stopPropagation();
            toggleItem(mainItem);
          }}
          className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center hover:bg-black/50 transition-colors"
        >
          <HeartIcon filled={wishlisted} />
        </button>

        {/* Hover CTA */}
        <div className="absolute inset-x-0 bottom-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          <button
            onClick={(e) => {
              e.stopPropagation();
              navigate(`/outfit/${combo.id}`);
            }}
            className="w-full btn-secondary text-sm py-2"
          >
            View Outfit
          </button>
        </div>
      </div>

      {/* Info */}
      <div className={`p-4 ${compact ? 'p-3' : ''}`}>
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className={`font-semibold ${compact ? 'text-sm' : 'text-base'} leading-tight`}>
            {combo.title}
          </h3>
          <span className="text-[10px] uppercase tracking-wider text-neutral-500 dark:text-neutral-400 capitalize shrink-0">
            {combo.gender}
          </span>
        </div>

        {!compact && (
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-2 line-clamp-1">
            {combo.items.map((i) => i.name).join(' + ')}
          </p>
        )}

        <div className="flex items-center gap-2">
          <span className="font-bold text-lg">{formatPrice(combo.totalAfterDiscount)}</span>
          <span className="text-xs text-neutral-500 line-through">
            {formatPrice(combo.totalBeforeDiscount)}
          </span>
          <span className="text-xs font-semibold text-green-600 dark:text-green-400">
            Save {formatPrice(savingsAmount)}
          </span>
        </div>
      </div>
    </motion.div>
  );
};

export default OutfitCard;
