import React from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useWishlistStore } from '../../store/wishlistStore';
import { useCartStore } from '../../store/cartStore';
import { formatPrice } from '../../utils/formatters';
import type { Item } from '../../types';
import ImageWithFallback from '../ui/ImageWithFallback';
import toast from 'react-hot-toast';

interface Props {
  item: Item;
  onOpenModal?: (item: Item) => void;
}

const StarIcon = () => (
  <svg className="w-3 h-3 fill-accent text-accent" viewBox="0 0 20 20">
    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
  </svg>
);

const ItemCard: React.FC<Props> = ({ item, onOpenModal }) => {
  const navigate = useNavigate();
  const { isWishlisted, toggleItem } = useWishlistStore();
  const { addItem } = useCartStore();
  const wishlisted = isWishlisted(item.id);

  const handleAddToCart = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (item.sizes.length === 1 && item.sizes[0] === 'One Size') {
      addItem(item, 'One Size', item.colors[0] || '');
      toast.success(`${item.name} added to cart!`, { icon: '🛍' });
    } else if (onOpenModal) {
      onOpenModal(item);
    } else {
      navigate(`/item/${item.id}`);
    }
  };

  return (
    <motion.div
      whileHover={{ y: -3 }}
      transition={{ duration: 0.2 }}
      className="card overflow-hidden cursor-pointer group"
      onClick={() => navigate(`/item/${item.id}`)}
      role="article"
      aria-label={item.name}
    >
      {/* Image */}
      <div className="relative aspect-square overflow-hidden">
        <ImageWithFallback
          src={item.imageUrl}
          alt={item.altText}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />

        {/* Top badges */}
        <div className="absolute top-2 left-2 flex flex-col gap-1">
          {item.isNew && (
            <span className="bg-accent text-accent-fg text-[9px] font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
              New
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button
          aria-label={wishlisted ? 'Remove from wishlist' : 'Add to wishlist'}
          onClick={(e) => {
            e.stopPropagation();
            toggleItem(item);
            toast(wishlisted ? 'Removed from wishlist' : 'Added to wishlist', {
              icon: wishlisted ? '💔' : '❤️',
            });
          }}
          className="absolute top-2 right-2 w-8 h-8 rounded-full bg-black/30 backdrop-blur-sm flex items-center justify-center hover:bg-black/50 transition-colors"
        >
          <svg
            className={`w-4 h-4 transition-colors ${wishlisted ? 'fill-red-500 text-red-500' : 'fill-none text-white'}`}
            viewBox="0 0 24 24"
            stroke="currentColor"
            strokeWidth={2}
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </button>

        {/* Add to cart hover overlay */}
        <div className="absolute inset-x-0 bottom-0 p-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={handleAddToCart}
            className="w-full btn-primary text-xs py-2"
          >
            Add to Cart
          </button>
        </div>
      </div>

      {/* Info */}
      <div className="p-3">
        <div className="flex items-center gap-1 mb-0.5">
          <StarIcon />
          <span className="text-[10px] text-neutral-500 dark:text-neutral-400">{item.rating}</span>
        </div>
        <h3 className="text-sm font-medium leading-tight mb-0.5 line-clamp-2">{item.name}</h3>
        <div className="flex items-center justify-between">
          <span className="font-bold text-sm">{formatPrice(item.price)}</span>
          <span className="text-[10px] text-neutral-400 capitalize">{item.category}</span>
        </div>
      </div>
    </motion.div>
  );
};

export default ItemCard;
