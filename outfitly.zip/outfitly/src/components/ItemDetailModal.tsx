import React, { useState } from 'react';
import Modal from './ui/Modal';
import { useCartStore } from '../store/cartStore';
import { useWishlistStore } from '../store/wishlistStore';
import { formatPrice } from '../utils/formatters';
import type { Item } from '../types';
import ImageWithFallback from './ui/ImageWithFallback';
import toast from 'react-hot-toast';

interface Props {
  item: Item | null;
  isOpen: boolean;
  onClose: () => void;
}

const ItemDetailModal: React.FC<Props> = ({ item, isOpen, onClose }) => {
  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const { addItem } = useCartStore();
  const { isWishlisted, toggleItem } = useWishlistStore();

  if (!item) return null;

  const wishlisted = isWishlisted(item.id);

  const handleAddToCart = () => {
    const needsSize = !(item.sizes.length === 1 && item.sizes[0] === 'One Size');
    if (needsSize && !selectedSize) {
      toast.error('Please select a size first!');
      return;
    }
    const size = needsSize ? selectedSize : 'One Size';
    const color = selectedColor || item.colors[0] || '';
    addItem(item, size, color);
    toast.success(`${item.name} added to cart! 🛍`, {
      style: { background: '#BBFF00', color: '#1A2E00', fontWeight: 600 },
    });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={item.name} maxWidth="max-w-3xl">
      <div className="flex flex-col md:flex-row max-h-[90vh] overflow-y-auto">
        {/* Image */}
        <div className="md:w-2/5 shrink-0">
          <div className="relative aspect-square md:aspect-[3/4]">
            <ImageWithFallback
              src={item.imageUrl}
              alt={item.altText}
              className="w-full h-full object-cover"
            />
            {item.isNew && (
              <span className="absolute top-3 left-3 bg-accent text-accent-fg text-[10px] font-bold px-2 py-1 rounded-full uppercase">
                New
              </span>
            )}
          </div>
        </div>

        {/* Details */}
        <div className="flex-1 p-6 flex flex-col gap-4">
          {/* Close */}
          <button
            aria-label="Close modal"
            onClick={onClose}
            className="absolute top-4 right-4 w-8 h-8 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>

          <div>
            <p className="text-xs uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-1 capitalize">
              {item.category} · {item.gender}
            </p>
            <h2 className="font-display text-3xl font-light">{item.name}</h2>
          </div>

          <div className="flex items-center gap-3">
            <span className="text-3xl font-bold">{formatPrice(item.price)}</span>
            <div className="flex gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <svg
                  key={s}
                  className={`w-4 h-4 ${s <= Math.floor(item.rating) ? 'fill-accent text-accent' : 'fill-neutral-200 text-neutral-200'}`}
                  viewBox="0 0 20 20"
                >
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
              <span className="text-xs text-neutral-500 ml-1">{item.rating}</span>
            </div>
          </div>

          <p className="text-sm text-neutral-600 dark:text-neutral-400">{item.description}</p>

          {/* Colors */}
          {item.colors.length > 0 && item.colors[0] !== '' && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2">
                Colour: <span className="text-neutral-500 font-normal normal-case">{selectedColor || item.colors[0]}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {item.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedColor(c)}
                    className={`px-3 py-1.5 text-xs rounded-full border transition-all ${
                      (selectedColor || item.colors[0]) === c
                        ? 'border-accent bg-accent/10 font-semibold text-accent-fg dark:text-accent'
                        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {!(item.sizes.length === 1 && item.sizes[0] === 'One Size') && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2">
                Size: {selectedSize && <span className="text-neutral-500 font-normal normal-case">{selectedSize}</span>}
                {!selectedSize && <span className="text-red-400 normal-case font-normal"> (required)</span>}
              </p>
              <div className="flex flex-wrap gap-2">
                {item.sizes.map((s) => (
                  <button
                    key={s}
                    onClick={() => setSelectedSize(s)}
                    className={`min-w-[44px] h-10 px-2 text-sm rounded-xl border transition-all font-medium ${
                      selectedSize === s
                        ? 'border-accent bg-accent text-accent-fg'
                        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Tags */}
          <div className="flex flex-wrap gap-1.5">
            {item.styleTags.map((tag) => (
              <span key={tag} className="text-[10px] px-2 py-1 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 capitalize">
                {tag}
              </span>
            ))}
          </div>

          {/* CTAs */}
          <div className="flex gap-3 mt-auto pt-2">
            <button onClick={handleAddToCart} className="flex-1 btn-primary">
              Add to Cart
            </button>
            <button
              aria-label={wishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
              onClick={() => toggleItem(item)}
              className={`w-12 h-12 rounded-full border flex items-center justify-center transition-all ${
                wishlisted
                  ? 'border-red-400 bg-red-50 dark:bg-red-900/20'
                  : 'border-neutral-200 dark:border-neutral-700 hover:border-red-400'
              }`}
            >
              <svg
                className={`w-5 h-5 ${wishlisted ? 'fill-red-500 text-red-500' : 'fill-none text-neutral-500'}`}
                viewBox="0 0 24 24"
                stroke="currentColor"
                strokeWidth={2}
              >
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button>
          </div>

          <p className="text-[10px] text-neutral-500 dark:text-neutral-500">
            Free delivery · Easy 7-day returns · Secure checkout
          </p>
        </div>
      </div>
    </Modal>
  );
};

export default ItemDetailModal;
