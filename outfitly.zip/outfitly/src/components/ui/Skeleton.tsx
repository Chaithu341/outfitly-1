import React from 'react';

interface SkeletonProps {
  className?: string;
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = '' }) => (
  <div className={`skeleton-pulse rounded-xl ${className}`} />
);

export const OutfitCardSkeleton: React.FC = () => (
  <div className="rounded-2xl overflow-hidden bg-white dark:bg-surface-dark border border-black/5 dark:border-white/5">
    <Skeleton className="aspect-[3/4] rounded-none" />
    <div className="p-4 space-y-2">
      <Skeleton className="h-5 w-2/3" />
      <Skeleton className="h-3 w-1/3" />
      <Skeleton className="h-4 w-1/2 mt-2" />
    </div>
  </div>
);

export const ItemCardSkeleton: React.FC = () => (
  <div className="rounded-2xl overflow-hidden bg-white dark:bg-surface-dark border border-black/5 dark:border-white/5">
    <Skeleton className="aspect-square rounded-none" />
    <div className="p-3 space-y-2">
      <Skeleton className="h-4 w-3/4" />
      <Skeleton className="h-3 w-1/2" />
    </div>
  </div>
);
