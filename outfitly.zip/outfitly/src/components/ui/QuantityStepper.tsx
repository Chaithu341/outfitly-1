import React from 'react';

interface Props {
  value: number;
  min?: number;
  max?: number;
  onChange: (val: number) => void;
  size?: 'sm' | 'md';
}

const QuantityStepper: React.FC<Props> = ({ value, min = 1, max = 10, onChange, size = 'md' }) => {
  const btnClass =
    size === 'sm'
      ? 'w-7 h-7 text-sm'
      : 'w-9 h-9 text-base';

  return (
    <div className="flex items-center border border-neutral-200 dark:border-neutral-700 rounded-full overflow-hidden">
      <button
        type="button"
        aria-label="Decrease quantity"
        disabled={value <= min}
        onClick={() => onChange(value - 1)}
        className={`${btnClass} flex items-center justify-center hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors`}
      >
        −
      </button>
      <span className={`${size === 'sm' ? 'px-2 text-sm' : 'px-3'} font-medium min-w-[2rem] text-center`}>
        {value}
      </span>
      <button
        type="button"
        aria-label="Increase quantity"
        disabled={value >= max}
        onClick={() => onChange(value + 1)}
        className={`${btnClass} flex items-center justify-center hover:bg-neutral-100 dark:hover:bg-neutral-800 disabled:opacity-30 disabled:cursor-not-allowed transition-colors`}
      >
        +
      </button>
    </div>
  );
};

export default QuantityStepper;
