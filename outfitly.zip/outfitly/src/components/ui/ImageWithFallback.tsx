import React, { useState } from 'react';

interface Props {
  src: string;
  alt: string;
  className?: string;
  fallbackClassName?: string;
}

const ImageWithFallback: React.FC<Props> = ({ src, alt, className = '', fallbackClassName = '' }) => {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  if (error) {
    return (
      <div
        className={`${className} ${fallbackClassName} flex flex-col items-center justify-center bg-gradient-to-br from-neutral-100 to-neutral-200 dark:from-neutral-800 dark:to-neutral-900`}
        role="img"
        aria-label={alt}
      >
        <svg className="w-8 h-8 text-neutral-400 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
        </svg>
        <span className="text-xs text-neutral-400">{alt}</span>
      </div>
    );
  }

  return (
    <>
      {!loaded && (
        <div className={`${className} skeleton-pulse`} />
      )}
      <img
        src={src}
        alt={alt}
        className={`${className} ${loaded ? 'opacity-100' : 'opacity-0 absolute'} transition-opacity duration-300`}
        onError={() => setError(true)}
        onLoad={() => setLoaded(true)}
        loading="lazy"
      />
    </>
  );
};

export default ImageWithFallback;
