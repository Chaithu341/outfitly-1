import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useCartStore } from '../../store/cartStore';
import { useWishlistStore } from '../../store/wishlistStore';

interface NavItemProps {
  to: string;
  label: string;
  active: boolean;
  badge?: number;
  icon: React.ReactNode;
}

const NavItem: React.FC<NavItemProps> = ({ to, label, active, badge, icon }) => (
  <Link
    to={to}
    aria-label={`${label}${badge ? ` (${badge})` : ''}`}
    className="relative flex flex-col items-center gap-0.5 px-3 py-1 min-w-0"
  >
    <div className={`relative transition-colors ${active ? 'text-accent' : 'text-neutral-500 dark:text-neutral-400'}`}>
      {icon}
      {badge != null && badge > 0 && (
        <span className="absolute -top-1 -right-1 w-4 h-4 bg-accent text-accent-fg text-[9px] font-bold rounded-full flex items-center justify-center">
          {badge > 9 ? '9+' : badge}
        </span>
      )}
    </div>
    <span className={`text-[9px] font-medium uppercase tracking-wide leading-none ${active ? 'text-accent' : 'text-neutral-500 dark:text-neutral-400'}`}>
      {label}
    </span>
    {active && (
      <span className="absolute top-0 left-1/2 -translate-x-1/2 w-4 h-0.5 bg-accent rounded-full" />
    )}
  </Link>
);

const BottomNav: React.FC = () => {
  const { pathname } = useLocation();
  const { itemCount } = useCartStore();
  const { items: wishlistItems } = useWishlistStore();

  return (
    <nav
      className="md:hidden fixed bottom-0 inset-x-0 z-40 glass border-t border-black/5 dark:border-white/8 flex items-center justify-around py-2 safe-area-bottom"
      role="navigation"
      aria-label="Main navigation"
    >
      <NavItem
        to="/"
        label="Home"
        active={pathname === '/'}
        icon={
          <svg className="w-6 h-6" fill={pathname === '/' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z" />
            <polyline points="9 22 9 12 15 12 15 22" />
          </svg>
        }
      />
      <NavItem
        to="/search"
        label="Search"
        active={pathname === '/search'}
        icon={
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        }
      />
      <NavItem
        to="/wishlist"
        label="Saved"
        active={pathname === '/wishlist'}
        badge={wishlistItems.length}
        icon={
          <svg className="w-6 h-6" fill={pathname === '/wishlist' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        }
      />
      <NavItem
        to="/cart"
        label="Cart"
        active={pathname === '/cart'}
        badge={itemCount}
        icon={
          <svg className="w-6 h-6" fill={pathname === '/cart' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
        }
      />
      <NavItem
        to="/orders"
        label="Profile"
        active={pathname === '/orders' || pathname === '/auth'}
        icon={
          <svg className="w-6 h-6" fill={pathname === '/orders' ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
          </svg>
        }
      />
    </nav>
  );
};

export default BottomNav;
