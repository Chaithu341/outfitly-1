import type { OutfitCombo } from '../types';
import { items } from './items';

const i = (id: string) => {
  const item = items.find((x) => x.id === id);
  if (!item) throw new Error(`Item not found: ${id}`);
  return item;
};

const makeCombo = (
  partial: Omit<OutfitCombo, 'totalBeforeDiscount' | 'totalAfterDiscount'>
): OutfitCombo => {
  const totalBeforeDiscount = partial.items.reduce((s, item) => s + item.price, 0);
  const totalAfterDiscount = Math.round(
    totalBeforeDiscount * (1 - partial.discountPercent / 100)
  );
  return { ...partial, totalBeforeDiscount, totalAfterDiscount };
};

export const combos: OutfitCombo[] = [
  // ─── BOYS ────────────────────────────────────────────────────────────
  makeCombo({
    id: 'combo-b-001',
    title: 'Urban Edge',
    description: 'Clean streetwear drip. Cargo + oversized + clean kicks = the look.',
    items: [i('top-b-001'), i('btm-b-001'), i('sho-b-001'), i('acc-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['streetwear', 'trending', 'bestseller'],
    trendingScore: 97,
    discountPercent: 12,
  }),
  makeCombo({
    id: 'combo-b-002',
    title: 'Dark Scholar',
    description: 'Hoodie-core meets dark academia. Library to streets.',
    items: [i('top-b-002'), i('btm-b-002'), i('sho-b-002')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['dark academia', 'minimal', 'trending'],
    trendingScore: 91,
    discountPercent: 10,
  }),
  makeCombo({
    id: 'combo-b-003',
    title: 'Minimal King',
    description: 'Less is more. Polo + chinos + clean whites = effortless style.',
    items: [i('top-b-003'), i('btm-b-004'), i('sho-b-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1499996755189-4f5b1de3aefb?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['minimal', 'preppy', 'classic'],
    trendingScore: 78,
    discountPercent: 8,
  }),
  makeCombo({
    id: 'combo-b-004',
    title: 'Y2K Flex',
    description: 'Bring back the early 2000s. Graphic + denim shorts + chunky sole.',
    items: [i('top-b-004'), i('btm-b-005'), i('sho-b-003'), i('acc-003')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1492446803736-a04b35a4f42c?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['y2k', 'streetwear', 'new'],
    trendingScore: 93,
    discountPercent: 11,
  }),
  makeCombo({
    id: 'combo-b-005',
    title: 'Athleisure Pro',
    description: 'From gym to street without changing. Performance meets aesthetic.',
    items: [i('top-b-005'), i('btm-b-003'), i('sho-b-002')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1617195820-c4df3b905ad1?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['athleisure', 'casual', 'comfy'],
    trendingScore: 82,
    discountPercent: 9,
  }),
  makeCombo({
    id: 'combo-b-006',
    title: 'Smart Casual',
    description: 'Office-ready but make it Gen Z. Polo + slim jeans + clean sneakers.',
    items: [i('top-b-003'), i('btm-b-002'), i('sho-b-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1491553895911-0055eca6402d?auto=format&fit=crop&w=800&q=80',
    gender: 'boys',
    tags: ['smart casual', 'work', 'minimal'],
    trendingScore: 74,
    discountPercent: 9,
  }),

  // ─── GIRLS ───────────────────────────────────────────────────────────
  makeCombo({
    id: 'combo-g-001',
    title: 'Soft Girl Era',
    description: 'Pastel vibes, wide legs, and platform energy. Aesthetic unlocked.',
    items: [i('top-g-004'), i('btm-g-004'), i('sho-g-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['soft girl', 'trending', 'y2k'],
    trendingScore: 96,
    discountPercent: 13,
  }),
  makeCombo({
    id: 'combo-g-002',
    title: 'Y2K Goddess',
    description: 'Full throwback energy. Crop + mini + platforms + gold chains.',
    items: [i('top-g-001'), i('btm-g-002'), i('sho-g-001'), i('acc-004')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1524504388940-b1c1722653e0?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['y2k', 'party', 'bestseller', 'trending'],
    trendingScore: 99,
    discountPercent: 15,
  }),
  makeCombo({
    id: 'combo-g-003',
    title: 'Clean Girl',
    description: 'The "no-makeup makeup" of fashion. White tee + mom jeans + chunky boots.',
    items: [i('top-g-002'), i('btm-g-001'), i('sho-g-002')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['clean girl', 'minimal', 'trending'],
    trendingScore: 94,
    discountPercent: 10,
  }),
  makeCombo({
    id: 'combo-g-004',
    title: 'Satin Dreams',
    description: 'Elevated casual. Satin cami + biker shorts + ballet flats + micro bag.',
    items: [i('top-g-003'), i('btm-g-005'), i('sho-g-003'), i('acc-002')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['elevated', 'party', 'minimal'],
    trendingScore: 88,
    discountPercent: 12,
  }),
  makeCombo({
    id: 'combo-g-005',
    title: 'Garden Party',
    description: 'Florals for spring? Groundbreaking. Blouse + plaid skirt + ballet flats.',
    items: [i('top-g-005'), i('btm-g-003'), i('sho-g-003')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1469334031218-e382a71b716b?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['floral', 'party', 'casual'],
    trendingScore: 76,
    discountPercent: 11,
  }),
  makeCombo({
    id: 'combo-g-006',
    title: 'Street Chic',
    description: 'Crop top energy with grown-up jeans. The contrast is the vibe.',
    items: [i('top-g-001'), i('btm-g-001'), i('sho-g-002'), i('acc-003')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1609205807007-67d428db0a74?auto=format&fit=crop&w=800&q=80',
    gender: 'girls',
    tags: ['streetwear', 'y2k', 'casual'],
    trendingScore: 89,
    discountPercent: 12,
  }),

  // ─── UNISEX ───────────────────────────────────────────────────────────
  makeCombo({
    id: 'combo-u-001',
    title: 'Monochrome Magic',
    description: 'All-white or all-black, you pick. The formula is foolproof.',
    items: [i('top-b-001'), i('btm-b-003'), i('sho-b-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['monochrome', 'minimal', 'classic'],
    trendingScore: 85,
    discountPercent: 9,
  }),
  makeCombo({
    id: 'combo-u-002',
    title: 'Street Supreme',
    description: 'Graphic + cargo + chunky + shades. The full streetwear starter pack.',
    items: [i('top-b-004'), i('btm-b-001'), i('sho-b-003'), i('acc-003')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['streetwear', 'bold', 'trending'],
    trendingScore: 92,
    discountPercent: 12,
  }),
  makeCombo({
    id: 'combo-u-003',
    title: 'Chill Mode',
    description: 'Hoodie, biker shorts, white sneakers. Comfort is the new luxury.',
    items: [i('top-b-002'), i('btm-g-005'), i('sho-b-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1536766768-bf5d7b3f8bf8?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['comfy', 'athleisure', 'casual'],
    trendingScore: 80,
    discountPercent: 10,
  }),
  makeCombo({
    id: 'combo-u-004',
    title: 'Beach Day Ready',
    description: 'Stripe knit + denim shorts + canvas kicks. Coastal cool.',
    items: [i('top-b-005'), i('btm-b-005'), i('sho-b-002')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['summer', 'casual', 'coastal'],
    trendingScore: 77,
    discountPercent: 8,
  }),
  makeCombo({
    id: 'combo-u-005',
    title: 'Night Out',
    description: 'Satin cami + slim jeans + chunky platforms. After-dark energy.',
    items: [i('top-g-003'), i('btm-b-002'), i('sho-b-003')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1536657464132-ffcaa0eab87c?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['night out', 'party', 'elevated'],
    trendingScore: 86,
    discountPercent: 11,
  }),
  makeCombo({
    id: 'combo-u-006',
    title: 'Studio Session',
    description: 'Creative day fit. Wide legs + graphic tee + dad cap = artist mode.',
    items: [i('top-b-004'), i('btm-g-004'), i('sho-b-001'), i('acc-001')],
    heroImageUrl:
      'https://images.unsplash.com/photo-1490481166-d8b9d0fad76c?auto=format&fit=crop&w=800&q=80',
    gender: 'unisex',
    tags: ['creative', 'casual', 'streetwear'],
    trendingScore: 83,
    discountPercent: 11,
  }),
];

export const getComboById = (id: string): OutfitCombo | undefined =>
  combos.find((c) => c.id === id);

export const trendingCombos = [...combos]
  .sort((a, b) => b.trendingScore - a.trendingScore)
  .slice(0, 6);

export const newCombos = combos.filter((c) => c.tags.includes('new') || c.trendingScore >= 90);
