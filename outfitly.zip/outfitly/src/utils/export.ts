import type { Order } from '../types';

export const exportOrdersJSON = (orders: Order[], filename = 'outfitly-orders.json') => {
  const blob = new Blob([JSON.stringify(orders, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

export const exportOrdersCSV = (orders: Order[], filename = 'outfitly-orders.csv') => {
  const headers = [
    'Order ID',
    'Date',
    'Customer',
    'Email',
    'Items',
    'Subtotal',
    'Discount',
    'Total',
    'Payment',
    'Status',
    'City',
    'State',
    'Pincode',
  ];

  const rows = orders.map((o) => {
    const itemNames = [
      ...o.items.map((ci) => `${ci.item.name} x${ci.quantity}`),
      ...o.bundles.map((cb) => `${cb.combo.title} (bundle) x${cb.quantity}`),
    ].join(' | ');

    return [
      o.id,
      new Date(o.createdAt).toLocaleDateString('en-IN'),
      o.userName,
      o.userEmail,
      `"${itemNames}"`,
      o.subtotal,
      o.discount,
      o.total,
      o.paymentMethod.toUpperCase(),
      o.status,
      o.address.city,
      o.address.state,
      o.address.pincode,
    ].join(',');
  });

  const csv = [headers.join(','), ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
};

export const copyOrderJSON = async (order: Order): Promise<boolean> => {
  try {
    await navigator.clipboard.writeText(JSON.stringify(order, null, 2));
    return true;
  } catch {
    return false;
  }
};
