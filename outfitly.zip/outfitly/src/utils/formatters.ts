export const formatPrice = (amount: number): string =>
  `₹${amount.toLocaleString('en-IN')}`;

export const formatDate = (isoString: string): string =>
  new Date(isoString).toLocaleDateString('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  });

export const generateOrderId = (): string => {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `OTF-${ts}-${rand}`;
};

export const truncate = (str: string, maxLen: number): string =>
  str.length > maxLen ? `${str.slice(0, maxLen)}…` : str;

export const getHotspotPosition = (category: string): { x: number; y: number } => {
  switch (category) {
    case 'top':
      return { x: 38, y: 28 };
    case 'bottom':
      return { x: 45, y: 60 };
    case 'shoes':
      return { x: 52, y: 84 };
    case 'accessory':
      return { x: 22, y: 14 };
    default:
      return { x: 50, y: 50 };
  }
};
