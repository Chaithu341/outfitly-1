import type { Order } from '../types';

/**
 * Sends order notification.
 * - Always logs full order to console
 * - If VITE_FORMSPREE_ID is set in .env.local, sends real email via Formspree (free)
 *   Setup: https://formspree.io → Create form → get ID → add to .env.local
 */
export const sendOrderNotification = async (order: Order): Promise<void> => {
  // Always log to console (mock)
  console.group(`[OUTFITLY ORDER #${order.id}]`);
  console.log('Customer:', order.userName, `<${order.userEmail}>`);
  console.log('Total: ₹' + order.total);
  console.log(
    'Items:',
    order.items.map((ci) => `${ci.item.name} x${ci.quantity}`).join(', ')
  );
  console.log(
    'Bundles:',
    order.bundles.map((cb) => `${cb.combo.title} x${cb.quantity}`).join(', ')
  );
  console.log('Address:', `${order.address.line1}, ${order.address.city}`);
  console.log('Payment:', order.paymentMethod.toUpperCase());
  console.log('Full order object:', order);
  console.groupEnd();

  // Optional: Real email via Formspree
  const formspreeId = import.meta.env.VITE_FORMSPREE_ID as string | undefined;
  if (formspreeId && formspreeId !== 'your_form_id_here') {
    try {
      const res = await fetch(`https://formspree.io/f/${formspreeId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          _subject: `🛍 New Outfitly Order #${order.id}`,
          orderId: order.id,
          customer: `${order.userName} (${order.userEmail})`,
          total: `₹${order.total}`,
          items: [
            ...order.items.map((ci) => `${ci.item.name} x${ci.quantity} @ ₹${ci.item.price}`),
            ...order.bundles.map(
              (cb) =>
                `[Bundle] ${cb.combo.title} x${cb.quantity} @ ₹${cb.combo.totalAfterDiscount}`
            ),
          ].join('\n'),
          deliveryAddress: `${order.address.fullName}, ${order.address.line1}, ${order.address.city}, ${order.address.state} - ${order.address.pincode}`,
          phone: order.address.phone,
          paymentMethod: order.paymentMethod.toUpperCase(),
          orderDate: new Date(order.createdAt).toLocaleString('en-IN'),
        }),
      });
      if (res.ok) {
        console.log('[OUTFITLY] Email notification sent via Formspree ✓');
      }
    } catch (err) {
      console.warn('[OUTFITLY] Formspree notification failed:', err);
    }
  }
};
