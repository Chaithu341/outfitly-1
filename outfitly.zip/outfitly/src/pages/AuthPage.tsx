import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion, AnimatePresence } from 'framer-motion';
import { useAuthStore } from '../store/authStore';
import toast from 'react-hot-toast';

const loginSchema = z.object({
  email: z.string().email('Enter a valid email'),
  password: z.string().min(8, 'Password must be at least 8 characters'),
});

const signupSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters'),
  email: z.string().email('Enter a valid email'),
  password: z
    .string()
    .min(8, 'Minimum 8 characters')
    .regex(/[A-Z]/, 'Must contain an uppercase letter')
    .regex(/[0-9]/, 'Must contain a number'),
  confirmPassword: z.string(),
}).refine((d) => d.password === d.confirmPassword, {
  message: "Passwords don't match",
  path: ['confirmPassword'],
});

type LoginForm = z.infer<typeof loginSchema>;
type SignupForm = z.infer<typeof signupSchema>;

const HERO_IMAGES = [
  'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=800&q=80',
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e0?auto=format&fit=crop&w=800&q=80',
];

const AuthPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, signup, continueAsGuest, user } = useAuthStore();
  const [mode, setMode] = useState<'login' | 'signup'>('login');
  const [heroIdx, setHeroIdx] = useState(0);
  const [showPw, setShowPw] = useState(false);
  const from = (location.state as { from?: string } | null)?.from ?? '/';

  useEffect(() => {
    if (user) navigate(from, { replace: true });
  }, [user, navigate, from]);

  useEffect(() => {
    const timer = setInterval(() => setHeroIdx((i) => (i + 1) % HERO_IMAGES.length), 4000);
    return () => clearInterval(timer);
  }, []);

  const {
    register: regLogin,
    handleSubmit: handleLogin,
    formState: { errors: loginErrors, isSubmitting: loginLoading },
  } = useForm<LoginForm>({ resolver: zodResolver(loginSchema) });

  const {
    register: regSignup,
    handleSubmit: handleSignup,
    formState: { errors: signupErrors, isSubmitting: signupLoading },
  } = useForm<SignupForm>({ resolver: zodResolver(signupSchema) });

  const onLogin = async (data: LoginForm) => {
    const result = login(data.email, data.password);
    if (result.success) {
      toast.success(result.message, { icon: '👋' });
      navigate(from, { replace: true });
    } else {
      toast.error(result.message);
    }
  };

  const onSignup = async (data: SignupForm) => {
    const result = signup(data.name, data.email, data.password);
    if (result.success) {
      toast.success(result.message, { icon: '🎉' });
      navigate(from, { replace: true });
    } else {
      toast.error(result.message);
    }
  };

  const handleGuest = () => {
    continueAsGuest();
    navigate('/', { replace: true });
  };

  const inputClass = (error?: { message?: string }) =>
    `input-field ${error ? 'border-red-400 focus:ring-red-400' : ''}`;

  return (
    <div className="min-h-screen flex overflow-hidden">
      {/* Left: hero image panel */}
      <div className="hidden md:block relative w-1/2 bg-neutral-900 overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.img
            key={heroIdx}
            src={HERO_IMAGES[heroIdx]}
            alt="Fashion model"
            initial={{ opacity: 0, scale: 1.05 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.8 }}
            className="absolute inset-0 w-full h-full object-cover"
          />
        </AnimatePresence>
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        <div className="absolute bottom-12 left-8 right-8">
          <p className="font-display text-4xl text-white font-light italic leading-tight mb-3">
            "Style is a way to say who you are without having to speak."
          </p>
          <p className="text-sm text-neutral-400">— Rachel Zoe</p>
          <div className="flex gap-1.5 mt-4">
            {HERO_IMAGES.map((_, i) => (
              <button
                key={i}
                onClick={() => setHeroIdx(i)}
                aria-label={`Slide ${i + 1}`}
                className={`h-1 rounded-full transition-all ${i === heroIdx ? 'w-6 bg-accent' : 'w-2 bg-white/30'}`}
              />
            ))}
          </div>
        </div>
        <div className="absolute top-8 left-8">
          <span className="font-display text-3xl text-white font-semibold">
            OUTFIT<span className="text-accent">LY</span>
          </span>
          <p className="text-xs text-neutral-400 mt-1 uppercase tracking-widest">Premium Gen Z Fashion</p>
        </div>
      </div>

      {/* Right: auth form */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-12 min-h-screen bg-bg-light dark:bg-bg-dark">
        {/* Mobile logo */}
        <div className="md:hidden mb-8 text-center">
          <span className="font-display text-4xl font-semibold">
            OUTFIT<span className="text-accent">LY</span>
          </span>
          <p className="text-xs text-neutral-500 mt-1 uppercase tracking-widest">Premium Gen Z Fashion</p>
        </div>

        <div className="w-full max-w-sm">
          {/* Tab toggle */}
          <div className="flex gap-1 p-1 bg-neutral-100 dark:bg-neutral-800 rounded-2xl mb-8">
            {(['login', 'signup'] as const).map((m) => (
              <button
                key={m}
                onClick={() => setMode(m)}
                className={`flex-1 py-2 text-sm font-semibold rounded-xl transition-all ${
                  mode === m
                    ? 'bg-white dark:bg-neutral-700 shadow-sm'
                    : 'text-neutral-500'
                }`}
              >
                {m === 'login' ? 'Sign In' : 'Sign Up'}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {mode === 'login' ? (
              <motion.form
                key="login"
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 16 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleLogin(onLogin)}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                  <input {...regLogin('email')} type="email" placeholder="you@example.com" className={inputClass(loginErrors.email)} />
                  {loginErrors.email && <p className="text-xs text-red-400 mt-1">{loginErrors.email.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Password</label>
                  <div className="relative">
                    <input {...regLogin('password')} type={showPw ? 'text' : 'password'} placeholder="••••••••" className={inputClass(loginErrors.password)} />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 text-xs">
                      {showPw ? 'Hide' : 'Show'}
                    </button>
                  </div>
                  {loginErrors.password && <p className="text-xs text-red-400 mt-1">{loginErrors.password.message}</p>}
                </div>
                <button type="submit" disabled={loginLoading} className="btn-primary w-full mt-6 disabled:opacity-70">
                  {loginLoading ? 'Signing in…' : 'Sign In'}
                </button>

                <div className="text-center text-xs text-neutral-500 dark:text-neutral-400 space-y-1 mt-2">
                  <p>Demo: <span className="font-mono">aryan@demo.com</span> / <span className="font-mono">Aryan@123</span></p>
                  <p>Admin: <span className="font-mono">admin@outfitly.demo</span> / <span className="font-mono">Admin@1234</span></p>
                </div>
              </motion.form>
            ) : (
              <motion.form
                key="signup"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleSignup(onSignup)}
                className="space-y-4"
              >
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name</label>
                  <input {...regSignup('name')} type="text" placeholder="Your name" className={inputClass(signupErrors.name)} />
                  {signupErrors.name && <p className="text-xs text-red-400 mt-1">{signupErrors.name.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Email</label>
                  <input {...regSignup('email')} type="email" placeholder="you@example.com" className={inputClass(signupErrors.email)} />
                  {signupErrors.email && <p className="text-xs text-red-400 mt-1">{signupErrors.email.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Password</label>
                  <div className="relative">
                    <input {...regSignup('password')} type={showPw ? 'text' : 'password'} placeholder="Min 8 chars, 1 uppercase, 1 number" className={inputClass(signupErrors.password)} />
                    <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 text-xs">
                      {showPw ? 'Hide' : 'Show'}
                    </button>
                  </div>
                  {signupErrors.password && <p className="text-xs text-red-400 mt-1">{signupErrors.password.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Confirm Password</label>
                  <input {...regSignup('confirmPassword')} type={showPw ? 'text' : 'password'} placeholder="Re-enter password" className={inputClass(signupErrors.confirmPassword)} />
                  {signupErrors.confirmPassword && <p className="text-xs text-red-400 mt-1">{signupErrors.confirmPassword.message}</p>}
                </div>
                <button type="submit" disabled={signupLoading} className="btn-primary w-full mt-6 disabled:opacity-70">
                  {signupLoading ? 'Creating account…' : 'Create Account'}
                </button>
              </motion.form>
            )}
          </AnimatePresence>

          <div className="mt-6 text-center">
            <button onClick={handleGuest} className="text-sm text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300 transition-colors underline underline-offset-2">
              Continue as Guest
            </button>
            <p className="text-xs text-neutral-400 mt-1">(Cart + wishlist available, checkout requires login)</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;
