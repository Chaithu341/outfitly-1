import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useCartStore } from '../store/cartStore';
import { useWishlistStore } from '../store/wishlistStore';
import { formatPrice } from '../utils/formatters';
import QuantityStepper from '../components/ui/QuantityStepper';
import ImageWithFallback from '../components/ui/ImageWithFallback';
import toast from 'react-hot-toast';

const CartPage: React.FC = () => {
  const navigate = useNavigate();
  const {
    items,
    bundles,
    removeItem,
    updateItemQty,
    removeBundle,
    updateBundleQty,
    subtotal,
    discount,
    total,
    itemCount,
  } = useCartStore();
  const { addItem: addToWishlist } = useWishlistStore();

  const moveToWishlist = (cartItem: (typeof items)[0]) => {
    addToWishlist(cartItem.item);
    removeItem(cartItem.item.id, cartItem.selectedSize);
    toast('Moved to wishlist ❤️', { duration: 2000 });
  };

  if (itemCount === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <div className="w-24 h-24 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-6">
          <svg className="w-12 h-12 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
          </svg>
        </div>
        <h2 className="font-display text-3xl font-light mb-2">Your cart is empty</h2>
        <p className="text-neutral-500 mb-8">Add some outfits and let's get you styled!</p>
        <button onClick={() => navigate('/search')} className="btn-primary">
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <h1 className="font-display text-4xl font-light mb-8">
        Your Cart <span className="text-neutral-400 text-2xl">({itemCount})</span>
      </h1>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Items list */}
        <div className="flex-1 space-y-4">
          {/* Bundles */}
          {bundles.map((bundle) => (
            <AnimatePresence key={bundle.combo.id}>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="card p-4"
              >
                <div className="flex items-start gap-4">
                  <img
                    src={bundle.combo.heroImageUrl}
                    alt={bundle.combo.title}
                    className="w-20 h-24 rounded-xl object-cover bg-neutral-100 shrink-0"
                    onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <span className="text-[10px] bg-accent/10 text-accent-fg dark:text-accent font-bold px-2 py-0.5 rounded-full uppercase tracking-wide">
                          Full Outfit Bundle
                        </span>
                        <h3 className="font-semibold mt-1">{bundle.combo.title}</h3>
                        <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                          {bundle.combo.items.map((i) => i.name).join(' · ')}
                        </p>
                      </div>
                      <button
                        aria-label="Remove bundle"
                        onClick={() => removeBundle(bundle.combo.id)}
                        className="text-neutral-400 hover:text-red-400 transition-colors shrink-0"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                      </button>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <QuantityStepper
                        value={bundle.quantity}
                        onChange={(q) => updateBundleQty(bundle.combo.id, q)}
                        size="sm"
                      />
                      <div className="text-right">
                        <p className="font-bold">{formatPrice(bundle.combo.totalAfterDiscount * bundle.quantity)}</p>
                        <p className="text-xs text-neutral-400 line-through">
                          {formatPrice(bundle.combo.totalBeforeDiscount * bundle.quantity)}
                        </p>
                        <p className="text-xs text-green-500 font-semibold">
                          -{bundle.combo.discountPercent}% saved
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          ))}

          {/* Individual items */}
          {items.map((cartItem) => (
            <AnimatePresence key={`${cartItem.item.id}-${cartItem.selectedSize}`}>
              <motion.div
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="card p-4"
              >
                <div className="flex items-start gap-4">
                  <ImageWithFallback
                    src={cartItem.item.imageUrl}
                    alt={cartItem.item.altText}
                    className="w-20 h-20 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <Link to={`/item/${cartItem.item.id}`} className="font-medium hover:text-accent transition-colors">
                          {cartItem.item.name}
                        </Link>
                        <div className="flex flex-wrap gap-1.5 mt-1">
                          {cartItem.selectedSize !== 'One Size' && (
                            <span className="text-[10px] text-neutral-500 bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded-full">
                              Size: {cartItem.selectedSize}
                            </span>
                          )}
                          {cartItem.selectedColor && (
                            <span className="text-[10px] text-neutral-500 bg-neutral-100 dark:bg-neutral-800 px-2 py-0.5 rounded-full">
                              {cartItem.selectedColor}
                            </span>
                          )}
                        </div>
                      </div>
                      <button
                        aria-label="Remove item"
                        onClick={() => removeItem(cartItem.item.id, cartItem.selectedSize)}
                        className="text-neutral-400 hover:text-red-400 transition-colors shrink-0"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                      </button>
                    </div>

                    <div className="flex items-center justify-between mt-3">
                      <div className="flex items-center gap-3">
                        <QuantityStepper
                          value={cartItem.quantity}
                          onChange={(q) => updateItemQty(cartItem.item.id, cartItem.selectedSize, q)}
                          size="sm"
                        />
                        <button
                          onClick={() => moveToWishlist(cartItem)}
                          className="text-xs text-neutral-500 hover:text-accent transition-colors underline underline-offset-2"
                        >
                          Save
                        </button>
                      </div>
                      <span className="font-bold">{formatPrice(cartItem.item.price * cartItem.quantity)}</span>
                    </div>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          ))}
        </div>

        {/* Order summary */}
        <div className="lg:w-80 xl:w-96 shrink-0">
          <div className="card p-6 sticky top-20">
            <h2 className="font-semibold text-lg mb-5">Order Summary</h2>

            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-neutral-500">Subtotal ({itemCount} items)</span>
                <span className="font-medium">{formatPrice(subtotal)}</span>
              </div>
              {discount > 0 && (
                <div className="flex justify-between text-green-500">
                  <span>Combo Discount</span>
                  <span className="font-semibold">-{formatPrice(discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-neutral-500">
                <span>Delivery</span>
                <span className="text-green-500 font-medium">FREE</span>
              </div>
              <div className="border-t border-neutral-100 dark:border-neutral-700 pt-3 flex justify-between text-base">
                <span className="font-semibold">Total</span>
                <span className="font-bold text-xl">{formatPrice(total)}</span>
              </div>
            </div>

            {discount > 0 && (
              <div className="mt-4 p-3 bg-green-50 dark:bg-green-900/20 rounded-xl text-sm text-green-700 dark:text-green-400">
                🎉 You're saving {formatPrice(discount)} on combo bundles!
              </div>
            )}

            <button
              onClick={() => navigate('/checkout')}
              className="btn-primary w-full mt-5 py-4 text-base"
            >
              Checkout — {formatPrice(total)}
            </button>

            <Link to="/search" className="block text-center text-sm text-accent hover:underline mt-3">
              Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
