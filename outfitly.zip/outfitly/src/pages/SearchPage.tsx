import React, { useState, useMemo, useCallback } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { items } from '../data/items';
import { combos } from '../data/combos';
import OutfitCard from '../components/cards/OutfitCard';
import ItemCard from '../components/cards/ItemCard';
import ItemDetailModal from '../components/ItemDetailModal';
import type { Item, Gender, StyleTag, Category } from '../types';

type Tab = 'combos' | 'singles';
type SortOption = 'trending' | 'price-asc' | 'price-desc' | 'new';

const STYLE_TAGS: StyleTag[] = ['streetwear', 'minimal', 'party', 'casual', 'y2k', 'preppy', 'athleisure'];
const GENDERS: Gender[] = ['boys', 'girls', 'unisex'];
const CATEGORIES: Category[] = ['top', 'bottom', 'shoes', 'accessory'];
const BUDGETS = [199, 299, 399, 499];

const FilterChip: React.FC<{ label: string; active: boolean; onClick: () => void }> = ({ label, active, onClick }) => (
  <button
    onClick={onClick}
    className={`px-3 py-1.5 text-xs font-medium rounded-full border transition-all capitalize whitespace-nowrap ${
      active
        ? 'bg-accent text-accent-fg border-accent'
        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400 dark:hover:border-neutral-500'
    }`}
  >
    {label}
  </button>
);

const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [tab, setTab] = useState<Tab>((searchParams.get('tab') as Tab) || 'combos');
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [budgetFilter, setBudgetFilter] = useState<number | null>(
    searchParams.get('budget') ? Number(searchParams.get('budget')) : null
  );
  const [styleFilter, setStyleFilter] = useState<StyleTag | null>(
    (searchParams.get('style') as StyleTag) || null
  );
  const [genderFilter, setGenderFilter] = useState<Gender | null>(
    (searchParams.get('gender') as Gender) || null
  );
  const [categoryFilter, setCategoryFilter] = useState<Category | null>(null);
  const [sort, setSort] = useState<SortOption>(
    (searchParams.get('sort') as SortOption) || 'trending'
  );
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [modalItem, setModalItem] = useState<Item | null>(null);

  const updateTab = (t: Tab) => {
    setTab(t);
    setSearchParams((prev) => { prev.set('tab', t); return prev; });
  };

  const filteredCombos = useMemo(() => {
    let result = [...combos];
    if (query) {
      const q = query.toLowerCase();
      result = result.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.description.toLowerCase().includes(q) ||
          c.tags.some((t) => t.includes(q)) ||
          c.items.some((i) => i.name.toLowerCase().includes(q))
      );
    }
    if (genderFilter) result = result.filter((c) => c.gender === genderFilter || c.gender === 'unisex');
    if (styleFilter) result = result.filter((c) => c.tags.some((t) => t === styleFilter));
    if (budgetFilter) result = result.filter((c) => c.totalAfterDiscount <= budgetFilter * 3);

    if (sort === 'trending') result.sort((a, b) => b.trendingScore - a.trendingScore);
    else if (sort === 'price-asc') result.sort((a, b) => a.totalAfterDiscount - b.totalAfterDiscount);
    else if (sort === 'price-desc') result.sort((a, b) => b.totalAfterDiscount - a.totalAfterDiscount);

    return result;
  }, [query, genderFilter, styleFilter, budgetFilter, sort]);

  const filteredItems = useMemo(() => {
    let result = [...items];
    if (query) {
      const q = query.toLowerCase();
      result = result.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.styleTags.some((t) => t.includes(q)) ||
          i.category.includes(q)
      );
    }
    if (genderFilter) result = result.filter((i) => i.gender === genderFilter || i.gender === 'unisex');
    if (styleFilter) result = result.filter((i) => i.styleTags.includes(styleFilter));
    if (categoryFilter) result = result.filter((i) => i.category === categoryFilter);
    if (budgetFilter) result = result.filter((i) => i.price <= budgetFilter);

    if (sort === 'trending') result.sort((a, b) => b.trendingScore - a.trendingScore);
    else if (sort === 'price-asc') result.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') result.sort((a, b) => b.price - a.price);
    else if (sort === 'new') result.sort((a) => (a.isNew ? -1 : 1));

    return result;
  }, [query, genderFilter, styleFilter, categoryFilter, budgetFilter, sort]);

  const clearFilters = useCallback(() => {
    setBudgetFilter(null);
    setStyleFilter(null);
    setGenderFilter(null);
    setCategoryFilter(null);
    setQuery('');
  }, []);

  const hasFilters = budgetFilter || styleFilter || genderFilter || categoryFilter || query;

  const FilterPanel = () => (
    <div className="space-y-5">
      {/* Gender */}
      <div>
        <p className="text-[10px] uppercase tracking-widest text-neutral-500 font-semibold mb-2">Gender</p>
        <div className="flex flex-wrap gap-2">
          {GENDERS.map((g) => (
            <FilterChip key={g} label={g} active={genderFilter === g} onClick={() => setGenderFilter(genderFilter === g ? null : g)} />
          ))}
        </div>
      </div>
      {/* Budget */}
      <div>
        <p className="text-[10px] uppercase tracking-widest text-neutral-500 font-semibold mb-2">Budget</p>
        <div className="flex flex-wrap gap-2">
          {BUDGETS.map((b) => (
            <FilterChip key={b} label={`Under ₹${b}`} active={budgetFilter === b} onClick={() => setBudgetFilter(budgetFilter === b ? null : b)} />
          ))}
        </div>
      </div>
      {/* Style */}
      <div>
        <p className="text-[10px] uppercase tracking-widest text-neutral-500 font-semibold mb-2">Style</p>
        <div className="flex flex-wrap gap-2">
          {STYLE_TAGS.map((s) => (
            <FilterChip key={s} label={s} active={styleFilter === s} onClick={() => setStyleFilter(styleFilter === s ? null : s)} />
          ))}
        </div>
      </div>
      {/* Category (singles only) */}
      {tab === 'singles' && (
        <div>
          <p className="text-[10px] uppercase tracking-widest text-neutral-500 font-semibold mb-2">Category</p>
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <FilterChip key={c} label={c} active={categoryFilter === c} onClick={() => setCategoryFilter(categoryFilter === c ? null : c)} />
            ))}
          </div>
        </div>
      )}
      {hasFilters && (
        <button onClick={clearFilters} className="text-xs text-red-400 hover:text-red-500 font-medium">
          Clear all filters ×
        </button>
      )}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Search bar */}
      <div className="relative mb-6">
        <svg className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search outfits, hoodies, sneakers…"
          className="input-field pl-10"
        />
        {query && (
          <button onClick={() => setQuery('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        )}
      </div>

      {/* Tab + sort + mobile filter toggle */}
      <div className="flex flex-wrap items-center gap-3 mb-6">
        {/* Tabs */}
        <div className="flex p-0.5 bg-neutral-100 dark:bg-neutral-800 rounded-xl">
          {(['combos', 'singles'] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => updateTab(t)}
              className={`px-4 py-1.5 text-sm font-medium rounded-[10px] transition-all ${
                tab === t ? 'bg-white dark:bg-neutral-700 shadow-sm' : 'text-neutral-500'
              }`}
            >
              {t === 'combos' ? 'Outfit Combos' : 'Single Items'}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2 ml-auto">
          {/* Sort */}
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortOption)}
            className="input-field py-1.5 text-sm w-auto"
            aria-label="Sort by"
          >
            <option value="trending">Trending</option>
            <option value="price-asc">Price: Low → High</option>
            <option value="price-desc">Price: High → Low</option>
            <option value="new">New Arrivals</option>
          </select>

          {/* Mobile filter button */}
          <button
            onClick={() => setFiltersOpen(true)}
            className="md:hidden btn-outline text-sm py-1.5 px-3 flex items-center gap-1.5"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
            Filters {hasFilters ? '•' : ''}
          </button>
        </div>
      </div>

      <div className="flex gap-8">
        {/* Desktop sidebar filters */}
        <aside className="hidden md:block w-56 shrink-0">
          <div className="sticky top-20">
            <h3 className="font-semibold mb-4 text-sm uppercase tracking-wider">Filters</h3>
            <FilterPanel />
          </div>
        </aside>

        {/* Results grid */}
        <div className="flex-1 min-w-0">
          {tab === 'combos' ? (
            <>
              <p className="text-xs text-neutral-500 mb-4">{filteredCombos.length} outfits found</p>
              {filteredCombos.length === 0 ? (
                <div className="text-center py-20 text-neutral-400">
                  <svg className="w-12 h-12 mx-auto mb-3 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  <p className="text-sm">No outfits match your filters</p>
                  <button onClick={clearFilters} className="text-accent text-xs mt-2 hover:underline">Clear filters</button>
                </div>
              ) : (
                <motion.div
                  layout
                  className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-5"
                >
                  {filteredCombos.map((combo) => (
                    <motion.div key={combo.id} layout animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
                      <OutfitCard combo={combo} />
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          ) : (
            <>
              <p className="text-xs text-neutral-500 mb-4">{filteredItems.length} items found</p>
              {filteredItems.length === 0 ? (
                <div className="text-center py-20 text-neutral-400">
                  <p className="text-sm">No items match your filters</p>
                  <button onClick={clearFilters} className="text-accent text-xs mt-2 hover:underline">Clear filters</button>
                </div>
              ) : (
                <motion.div layout className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
                  {filteredItems.map((item) => (
                    <motion.div key={item.id} layout animate={{ opacity: 1 }} initial={{ opacity: 0 }}>
                      <ItemCard item={item} onOpenModal={setModalItem} />
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </>
          )}
        </div>
      </div>

      {/* Mobile bottom sheet filters */}
      <AnimatePresence>
        {filtersOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setFiltersOpen(false)}
              className="fixed inset-0 z-40 bg-black/50"
            />
            <motion.div
              initial={{ y: '100%' }}
              animate={{ y: 0 }}
              exit={{ y: '100%' }}
              transition={{ type: 'spring', damping: 30, stiffness: 300 }}
              className="fixed bottom-0 inset-x-0 z-50 bg-white dark:bg-neutral-900 rounded-t-3xl p-6 max-h-[80vh] overflow-y-auto"
            >
              <div className="flex items-center justify-between mb-6">
                <h3 className="font-semibold text-base">Filters</h3>
                <button onClick={() => setFiltersOpen(false)} className="text-neutral-400 hover:text-neutral-600">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              </div>
              <FilterPanel />
              <button onClick={() => setFiltersOpen(false)} className="btn-primary w-full mt-6">
                Apply Filters
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>

      <ItemDetailModal item={modalItem} isOpen={!!modalItem} onClose={() => setModalItem(null)} />
    </div>
  );
};

export default SearchPage;
