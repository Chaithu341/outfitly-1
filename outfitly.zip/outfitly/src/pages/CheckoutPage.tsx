import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { motion } from 'framer-motion';
import { useAuthStore } from '../store/authStore';
import { useCartStore } from '../store/cartStore';
import { useOrderStore } from '../store/orderStore';
import { formatPrice, generateOrderId } from '../utils/formatters';
import { sendOrderNotification } from '../utils/notify';
import type { Order, Address, PaymentMethod } from '../types';
import ImageWithFallback from '../components/ui/ImageWithFallback';
import toast from 'react-hot-toast';

const addressSchema = z.object({
  fullName: z.string().min(2, 'Enter full name'),
  phone: z.string().regex(/^\d{10}$/, 'Enter a valid 10-digit phone number'),
  line1: z.string().min(5, 'Enter street address'),
  line2: z.string().optional(),
  city: z.string().min(2, 'Enter city'),
  state: z.string().min(2, 'Enter state'),
  pincode: z.string().regex(/^\d{6}$/, 'Enter a valid 6-digit pincode'),
});

type AddressForm = z.infer<typeof addressSchema>;

const PAYMENT_METHODS: { id: PaymentMethod; label: string; icon: string; desc: string }[] = [
  { id: 'upi', label: 'UPI', icon: '📱', desc: 'Pay via any UPI app' },
  { id: 'card', label: 'Credit / Debit Card', icon: '💳', desc: 'All major cards accepted' },
  { id: 'cod', label: 'Cash on Delivery', icon: '💵', desc: 'Pay when you receive' },
];

const CheckoutPage: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { items, bundles, subtotal, discount, total, clearCart } = useCartStore();
  const { addOrder } = useOrderStore();
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('upi');
  const [isPlacing, setIsPlacing] = useState(false);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<AddressForm>({ resolver: zodResolver(addressSchema) });

  if (!user) {
    navigate('/auth', { state: { from: '/checkout' } });
    return null;
  }

  if (items.length === 0 && bundles.length === 0) {
    navigate('/cart');
    return null;
  }

  const onSubmit = async (addressData: AddressForm) => {
    setIsPlacing(true);
    try {
      const address: Address = addressData;
      const order: Order = {
        id: generateOrderId(),
        userId: user.id,
        userEmail: user.email,
        userName: user.name,
        items,
        bundles,
        subtotal,
        discount,
        total,
        address,
        paymentMethod,
        status: 'placed',
        createdAt: new Date().toISOString(),
      };

      // Simulate processing delay
      await new Promise((r) => setTimeout(r, 1200));

      addOrder(order);
      await sendOrderNotification(order);
      clearCart();

      toast.success('Order placed successfully! 🎉', {
        style: { background: '#BBFF00', color: '#1A2E00', fontWeight: 700 },
        duration: 4000,
      });
      navigate(`/success/${order.id}`);
    } catch (err) {
      console.error(err);
      toast.error('Something went wrong. Please try again.');
    } finally {
      setIsPlacing(false);
    }
  };

  const inputCls = (error?: { message?: string }) =>
    `input-field ${error ? 'border-red-400 focus:ring-red-400' : ''}`;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button onClick={() => navigate('/cart')} className="flex items-center gap-2 text-sm text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300 mb-6 transition-colors">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
        Back to Cart
      </button>

      <h1 className="font-display text-4xl font-light mb-8">Checkout</h1>

      {/* Formspree info banner */}
      <div className="mb-6 p-3 bg-neutral-100 dark:bg-neutral-800 rounded-xl text-xs text-neutral-500 dark:text-neutral-400 flex items-start gap-2">
        <svg className="w-4 h-4 text-accent shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
        <span>Order details are saved locally and logged to console. To receive real email notifications, add your Formspree ID to <code className="bg-neutral-200 dark:bg-neutral-700 px-1 rounded">.env.local</code> (see <code>.env.example</code>).</span>
      </div>

      <form onSubmit={handleSubmit(onSubmit)}>
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Left: Address + payment */}
          <div className="flex-1 space-y-8">
            {/* Address */}
            <section className="card p-6">
              <h2 className="font-semibold text-lg mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-accent text-accent-fg rounded-full text-xs font-bold flex items-center justify-center">1</span>
                Delivery Address
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Full Name *</label>
                  <input {...register('fullName')} placeholder="As on ID / door" className={inputCls(errors.fullName)} />
                  {errors.fullName && <p className="text-xs text-red-400 mt-1">{errors.fullName.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Phone *</label>
                  <input {...register('phone')} type="tel" placeholder="10-digit mobile" className={inputCls(errors.phone)} />
                  {errors.phone && <p className="text-xs text-red-400 mt-1">{errors.phone.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Pincode *</label>
                  <input {...register('pincode')} placeholder="6-digit pincode" className={inputCls(errors.pincode)} />
                  {errors.pincode && <p className="text-xs text-red-400 mt-1">{errors.pincode.message}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Street Address *</label>
                  <input {...register('line1')} placeholder="Flat no., Street, Area" className={inputCls(errors.line1)} />
                  {errors.line1 && <p className="text-xs text-red-400 mt-1">{errors.line1.message}</p>}
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">Landmark / Apt (optional)</label>
                  <input {...register('line2')} placeholder="Near..." className="input-field" />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">City *</label>
                  <input {...register('city')} placeholder="Mumbai" className={inputCls(errors.city)} />
                  {errors.city && <p className="text-xs text-red-400 mt-1">{errors.city.message}</p>}
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider mb-1.5">State *</label>
                  <input {...register('state')} placeholder="Maharashtra" className={inputCls(errors.state)} />
                  {errors.state && <p className="text-xs text-red-400 mt-1">{errors.state.message}</p>}
                </div>
              </div>
            </section>

            {/* Payment */}
            <section className="card p-6">
              <h2 className="font-semibold text-lg mb-5 flex items-center gap-2">
                <span className="w-7 h-7 bg-accent text-accent-fg rounded-full text-xs font-bold flex items-center justify-center">2</span>
                Payment Method
              </h2>
              <div className="space-y-3">
                {PAYMENT_METHODS.map((pm) => (
                  <label
                    key={pm.id}
                    className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                      paymentMethod === pm.id
                        ? 'border-accent bg-accent/5 dark:bg-accent/5'
                        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name="payment"
                      value={pm.id}
                      checked={paymentMethod === pm.id}
                      onChange={() => setPaymentMethod(pm.id)}
                      className="sr-only"
                    />
                    <span className="text-2xl">{pm.icon}</span>
                    <div>
                      <p className="font-semibold text-sm">{pm.label}</p>
                      <p className="text-xs text-neutral-500 dark:text-neutral-400">{pm.desc}</p>
                    </div>
                    <div className={`ml-auto w-5 h-5 rounded-full border-2 transition-all flex items-center justify-center ${
                      paymentMethod === pm.id ? 'border-accent' : 'border-neutral-300 dark:border-neutral-600'
                    }`}>
                      {paymentMethod === pm.id && <div className="w-2.5 h-2.5 rounded-full bg-accent" />}
                    </div>
                  </label>
                ))}
              </div>
            </section>
          </div>

          {/* Right: Order summary */}
          <div className="lg:w-80 xl:w-96 shrink-0">
            <div className="card p-6 sticky top-20">
              <h2 className="font-semibold text-lg mb-4">Order Summary</h2>

              {/* Items preview */}
              <div className="space-y-3 mb-5 max-h-60 overflow-y-auto scrollbar-hide">
                {bundles.map((b) => (
                  <div key={b.combo.id} className="flex items-center gap-3">
                    <img src={b.combo.heroImageUrl} alt={b.combo.title} className="w-12 h-14 rounded-xl object-cover bg-neutral-100" onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{b.combo.title}</p>
                      <p className="text-[10px] text-neutral-500">Bundle × {b.quantity}</p>
                    </div>
                    <span className="text-sm font-semibold shrink-0">{formatPrice(b.combo.totalAfterDiscount * b.quantity)}</span>
                  </div>
                ))}
                {items.map((ci) => (
                  <div key={`${ci.item.id}-${ci.selectedSize}`} className="flex items-center gap-3">
                    <ImageWithFallback src={ci.item.imageUrl} alt={ci.item.altText} className="w-12 h-12 rounded-xl object-cover" />
                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium truncate">{ci.item.name}</p>
                      <p className="text-[10px] text-neutral-500">{ci.selectedSize} × {ci.quantity}</p>
                    </div>
                    <span className="text-sm font-semibold shrink-0">{formatPrice(ci.item.price * ci.quantity)}</span>
                  </div>
                ))}
              </div>

              <div className="border-t border-neutral-100 dark:border-neutral-700 pt-4 space-y-2 text-sm">
                <div className="flex justify-between text-neutral-500">
                  <span>Subtotal</span>
                  <span>{formatPrice(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between text-green-500">
                    <span>Discount</span>
                    <span>-{formatPrice(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-500">
                  <span>Delivery</span>
                  <span className="text-green-500">FREE</span>
                </div>
                <div className="flex justify-between font-bold text-lg pt-2 border-t border-neutral-100 dark:border-neutral-700">
                  <span>Total</span>
                  <span>{formatPrice(total)}</span>
                </div>
              </div>

              <motion.button
                type="submit"
                disabled={isPlacing}
                whileTap={{ scale: 0.98 }}
                className="btn-primary w-full mt-5 py-4 text-base disabled:opacity-70 flex items-center justify-center gap-2"
              >
                {isPlacing ? (
                  <>
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Placing Order…
                  </>
                ) : (
                  `Place Order — ${formatPrice(total)}`
                )}
              </motion.button>

              <p className="text-[10px] text-neutral-500 text-center mt-3">
                By placing order you agree to our demo terms. No real money charged.
              </p>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
};

export default CheckoutPage;
