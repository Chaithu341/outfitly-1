import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getItemById, items as allItems } from '../data/items';
import { combos } from '../data/combos';
import { useCartStore } from '../store/cartStore';
import { useWishlistStore } from '../store/wishlistStore';
import { formatPrice } from '../utils/formatters';
import ItemCard from '../components/cards/ItemCard';
import OutfitCard from '../components/cards/OutfitCard';
import ItemDetailModal from '../components/ItemDetailModal';
import type { Item } from '../types';
import toast from 'react-hot-toast';

const ItemDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const item = id ? getItemById(id) : null;
  const { addItem } = useCartStore();
  const { isWishlisted, toggleItem } = useWishlistStore();

  const [selectedSize, setSelectedSize] = useState('');
  const [selectedColor, setSelectedColor] = useState('');
  const [modalItem, setModalItem] = useState<Item | null>(null);

  if (!item) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl mb-4">Item not found</p>
          <button onClick={() => navigate('/search')} className="btn-primary">Browse Items</button>
        </div>
      </div>
    );
  }

  const wishlisted = isWishlisted(item.id);
  const needsSize = !(item.sizes.length === 1 && item.sizes[0] === 'One Size');

  const handleAddToCart = () => {
    if (needsSize && !selectedSize) {
      toast.error('Please select a size first!');
      return;
    }
    addItem(item, selectedSize || 'One Size', selectedColor || item.colors[0] || '');
    toast.success(`${item.name} added to cart! 🛍`, {
      style: { background: '#BBFF00', color: '#1A2E00', fontWeight: 600 },
    });
  };

  // Pairs well with: items from same style tags, different category
  const pairsWellWith = allItems
    .filter((i) => i.id !== item.id && i.category !== item.category)
    .filter((i) => i.styleTags.some((t) => item.styleTags.includes(t)))
    .slice(0, 4);

  // Related combos
  const relatedCombos = combos
    .filter((c) => c.items.some((i) => i.id === item.id) || c.items.some((i) => i.styleTags.some((t) => item.styleTags.includes(t))))
    .slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center gap-2 text-sm text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300 mb-6 transition-colors"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Back
      </button>

      <div className="grid md:grid-cols-2 gap-8 xl:gap-16">
        {/* Image */}
        <div className="relative aspect-square md:aspect-[3/4] rounded-3xl overflow-hidden bg-neutral-100 dark:bg-neutral-800">
          <img
            src={item.imageUrl}
            alt={item.altText}
            className="w-full h-full object-cover"
            onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }}
          />
          {item.isNew && (
            <div className="absolute top-4 left-4">
              <span className="bg-accent text-accent-fg font-bold text-xs px-3 py-1 rounded-full uppercase tracking-wide">
                New Drop
              </span>
            </div>
          )}
        </div>

        {/* Details */}
        <div className="flex flex-col gap-5">
          <div>
            <p className="text-xs uppercase tracking-widest text-neutral-500 mb-1 capitalize">
              {item.category} · {item.gender}
            </p>
            <h1 className="font-display text-4xl md:text-5xl font-light leading-tight">{item.name}</h1>
          </div>

          <div className="flex items-center gap-4">
            <span className="text-4xl font-bold">{formatPrice(item.price)}</span>
            <div className="flex items-center gap-1">
              {[1, 2, 3, 4, 5].map((s) => (
                <svg key={s} className={`w-4 h-4 ${s <= Math.floor(item.rating) ? 'fill-accent text-accent' : 'fill-neutral-200 text-neutral-200'}`} viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
              <span className="text-sm text-neutral-500 ml-1">{item.rating}</span>
            </div>
          </div>

          <p className="text-neutral-600 dark:text-neutral-400">{item.description}</p>

          {/* Style tags */}
          <div className="flex flex-wrap gap-2">
            {item.styleTags.map((tag) => (
              <span key={tag} className="text-xs px-3 py-1 rounded-full bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-400 capitalize">
                #{tag}
              </span>
            ))}
          </div>

          {/* Colors */}
          {item.colors.length > 0 && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2">
                Colour: <span className="text-neutral-500 font-normal normal-case">{selectedColor || item.colors[0]}</span>
              </p>
              <div className="flex flex-wrap gap-2">
                {item.colors.map((c) => (
                  <button
                    key={c}
                    onClick={() => setSelectedColor(c)}
                    className={`px-3 py-1.5 text-sm rounded-full border transition-all ${
                      (selectedColor || item.colors[0]) === c
                        ? 'border-accent bg-accent/10 text-accent-fg dark:text-accent font-semibold'
                        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    {c}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Sizes */}
          {needsSize && (
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider mb-2">
                Size {!selectedSize && <span className="text-red-400 font-normal normal-case">(Select a size)</span>}
              </p>
              <div className="flex flex-wrap gap-2">
                {item.sizes.map((s) => (
                  <motion.button
                    key={s}
                    whileTap={{ scale: 0.95 }}
                    onClick={() => setSelectedSize(s)}
                    className={`min-w-[44px] h-11 px-3 text-sm rounded-xl border font-medium transition-all ${
                      selectedSize === s
                        ? 'border-accent bg-accent text-accent-fg'
                        : 'border-neutral-200 dark:border-neutral-700 hover:border-neutral-400'
                    }`}
                  >
                    {s}
                  </motion.button>
                ))}
              </div>
            </div>
          )}

          {/* Sticky mobile CTAs */}
          <div className="flex gap-3 sticky bottom-20 md:bottom-0 md:relative bg-bg-light dark:bg-bg-dark py-4 md:py-0 -mx-4 px-4 md:mx-0 md:px-0 mt-auto">
            <button onClick={handleAddToCart} className="flex-1 btn-primary py-4">
              Add to Cart — {formatPrice(item.price)}
            </button>
            <button
              aria-label={wishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
              onClick={() => {
                toggleItem(item);
                toast(wishlisted ? 'Removed from wishlist' : 'Saved to wishlist', { icon: wishlisted ? '💔' : '❤️' });
              }}
              className={`w-14 h-14 rounded-full border-2 flex items-center justify-center transition-all ${
                wishlisted ? 'border-red-400 bg-red-50 dark:bg-red-900/20' : 'border-neutral-200 dark:border-neutral-700'
              }`}
            >
              <svg className={`w-5 h-5 ${wishlisted ? 'fill-red-500 text-red-500' : 'fill-none text-neutral-500'}`} viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
              </svg>
            </button>
          </div>

          <p className="text-[11px] text-neutral-500 flex items-center gap-1.5">
            <svg className="w-3.5 h-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Free delivery · Easy 7-day returns · Secure checkout
          </p>
        </div>
      </div>

      {/* Pairs well with */}
      {pairsWellWith.length > 0 && (
        <section className="mt-16">
          <div className="mb-6">
            <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">Style it up</p>
            <h2 className="font-display text-3xl font-light">Pairs Well With</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {pairsWellWith.map((i) => (
              <ItemCard key={i.id} item={i} onOpenModal={setModalItem} />
            ))}
          </div>
        </section>
      )}

      {/* Related combos */}
      {relatedCombos.length > 0 && (
        <section className="mt-16">
          <div className="mb-6">
            <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">Full fits</p>
            <h2 className="font-display text-3xl font-light">Part of These Outfits</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
            {relatedCombos.map((c) => (
              <OutfitCard key={c.id} combo={c} compact />
            ))}
          </div>
        </section>
      )}

      <ItemDetailModal item={modalItem} isOpen={!!modalItem} onClose={() => setModalItem(null)} />
    </div>
  );
};

export default ItemDetailPage;
