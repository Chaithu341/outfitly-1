import React from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useOrderStore } from '../store/orderStore';
import { formatPrice, formatDate } from '../utils/formatters';
import { exportOrdersJSON, exportOrdersCSV, copyOrderJSON } from '../utils/export';
import toast from 'react-hot-toast';

const SuccessPage: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { getAllOrders } = useOrderStore();
  const order = getAllOrders().find((o) => o.id === orderId);

  if (!order) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center px-4 text-center">
        <div>
          <p className="text-xl mb-4 text-neutral-500">Order not found</p>
          <button onClick={() => navigate('/')} className="btn-primary">Go Home</button>
        </div>
      </div>
    );
  }

  const handleCopy = async () => {
    const ok = await copyOrderJSON(order);
    toast(ok ? '✓ Order JSON copied to clipboard!' : 'Copy failed — check browser permissions', {
      icon: ok ? '📋' : '❌',
    });
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-16 text-center">
      {/* Success animation */}
      <motion.div
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        transition={{ type: 'spring', stiffness: 260, damping: 20 }}
        className="w-24 h-24 bg-accent rounded-full flex items-center justify-center mx-auto mb-6"
      >
        <svg className="w-12 h-12 text-accent-fg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
        </svg>
      </motion.div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <h1 className="font-display text-4xl font-light mb-2">Order Placed! 🎉</h1>
        <p className="text-neutral-500 mb-2">Your order has been confirmed and is being processed.</p>
        <p className="text-sm text-neutral-400">
          Order <span className="font-mono font-semibold text-neutral-600 dark:text-neutral-300">{order.id}</span> · {formatDate(order.createdAt)}
        </p>
      </motion.div>

      {/* Order summary card */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="card p-6 mt-8 text-left"
      >
        <h2 className="font-semibold mb-4">Order Details</h2>

        <div className="space-y-2 mb-4">
          {order.bundles.map((b) => (
            <div key={b.combo.id} className="flex justify-between text-sm">
              <span>{b.combo.title} (Bundle) × {b.quantity}</span>
              <span className="font-semibold">{formatPrice(b.combo.totalAfterDiscount * b.quantity)}</span>
            </div>
          ))}
          {order.items.map((ci) => (
            <div key={`${ci.item.id}-${ci.selectedSize}`} className="flex justify-between text-sm">
              <span>{ci.item.name} × {ci.quantity}</span>
              <span className="font-semibold">{formatPrice(ci.item.price * ci.quantity)}</span>
            </div>
          ))}
        </div>

        <div className="border-t border-neutral-100 dark:border-neutral-700 pt-3 space-y-1 text-sm">
          {order.discount > 0 && (
            <div className="flex justify-between text-green-500">
              <span>Discount saved</span>
              <span>-{formatPrice(order.discount)}</span>
            </div>
          )}
          <div className="flex justify-between font-bold text-base pt-1">
            <span>Total Paid</span>
            <span>{formatPrice(order.total)}</span>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-neutral-100 dark:border-neutral-700 text-sm text-neutral-500 space-y-1">
          <p><span className="font-medium text-neutral-700 dark:text-neutral-300">Deliver to:</span> {order.address.fullName}, {order.address.line1}, {order.address.city}</p>
          <p><span className="font-medium text-neutral-700 dark:text-neutral-300">Payment:</span> {order.paymentMethod.toUpperCase()}</p>
          <p><span className="font-medium text-neutral-700 dark:text-neutral-300">Status:</span> <span className="text-green-500 font-semibold capitalize">{order.status}</span></p>
        </div>
      </motion.div>

      {/* Export actions */}
      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7 }}
        className="mt-6 grid grid-cols-3 gap-3"
      >
        <button
          onClick={() => exportOrdersJSON([order], `order-${order.id}.json`)}
          className="btn-outline text-xs py-2.5 flex flex-col items-center gap-1"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          Download JSON
        </button>
        <button
          onClick={() => exportOrdersCSV([order], `order-${order.id}.csv`)}
          className="btn-outline text-xs py-2.5 flex flex-col items-center gap-1"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          Download CSV
        </button>
        <button
          onClick={handleCopy}
          className="btn-outline text-xs py-2.5 flex flex-col items-center gap-1"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
          Copy JSON
        </button>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.9 }}
        className="flex flex-col sm:flex-row gap-3 mt-8"
      >
        <Link to="/orders" className="flex-1 btn-secondary text-center">
          View My Orders
        </Link>
        <Link to="/" className="flex-1 btn-outline text-center">
          Continue Shopping
        </Link>
      </motion.div>
    </div>
  );
};

export default SuccessPage;
