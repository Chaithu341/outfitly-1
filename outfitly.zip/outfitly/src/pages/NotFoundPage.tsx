import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFoundPage: React.FC = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-[80vh] flex flex-col items-center justify-center px-4 text-center">
      <p className="font-display text-[8rem] leading-none font-light text-neutral-200 dark:text-neutral-800 select-none">
        404
      </p>
      <h1 className="font-display text-3xl font-light -mt-4 mb-3">Page Not Found</h1>
      <p className="text-neutral-500 mb-8">The outfit you're looking for doesn't exist (yet).</p>
      <div className="flex gap-3">
        <button onClick={() => navigate(-1)} className="btn-outline">Go Back</button>
        <button onClick={() => navigate('/')} className="btn-primary">Home</button>
      </div>
    </div>
  );
};

export default NotFoundPage;
