import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { useOrderStore } from '../store/orderStore';
import { formatPrice, formatDate } from '../utils/formatters';
import { exportOrdersJSON, exportOrdersCSV } from '../utils/export';
import toast from 'react-hot-toast';

const STATUS_COLORS: Record<string, string> = {
  placed: 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400',
  confirmed: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  shipped: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  delivered: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
};

const OrdersPage: React.FC = () => {
  const navigate = useNavigate();
  const { user, logout } = useAuthStore();
  const { getUserOrders } = useOrderStore();

  if (!user) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <p className="text-xl mb-4 font-display font-light">Sign in to view your orders</p>
        <button onClick={() => navigate('/auth')} className="btn-primary">Sign In</button>
      </div>
    );
  }

  const orders = getUserOrders(user.id);

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      {/* Profile header */}
      <div className="card p-6 mb-8">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full bg-accent text-accent-fg text-2xl font-bold flex items-center justify-center">
            {user.name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1">
            <h1 className="font-semibold text-lg">{user.name}</h1>
            <p className="text-sm text-neutral-500">{user.email}</p>
            {user.isAdmin && (
              <span className="text-[10px] bg-accent text-accent-fg px-2 py-0.5 rounded-full font-bold uppercase">Admin</span>
            )}
          </div>
          <div className="flex flex-col gap-2">
            {user.isAdmin && (
              <button onClick={() => navigate('/admin')} className="btn-primary text-xs py-1.5">
                Admin Panel
              </button>
            )}
            <button
              onClick={() => { logout(); navigate('/'); toast('Signed out 👋'); }}
              className="btn-outline text-xs py-1.5"
            >
              Sign Out
            </button>
          </div>
        </div>
      </div>

      <div className="flex items-center justify-between mb-6">
        <h2 className="font-display text-3xl font-light">My Orders</h2>
        {orders.length > 0 && (
          <div className="flex gap-2">
            <button onClick={() => exportOrdersJSON(orders)} className="btn-outline text-xs py-1.5 px-3">
              JSON
            </button>
            <button onClick={() => exportOrdersCSV(orders)} className="btn-outline text-xs py-1.5 px-3">
              CSV
            </button>
          </div>
        )}
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-neutral-500 mb-4">No orders yet.</p>
          <button onClick={() => navigate('/search')} className="btn-primary">Start Shopping</button>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => (
            <div key={order.id} className="card p-5">
              <div className="flex flex-wrap items-start justify-between gap-3 mb-4">
                <div>
                  <p className="font-mono text-xs text-neutral-500">{order.id}</p>
                  <p className="font-semibold">{formatDate(order.createdAt)}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`text-xs font-semibold px-2.5 py-1 rounded-full capitalize ${STATUS_COLORS[order.status] || ''}`}>
                    {order.status}
                  </span>
                  <span className="font-bold">{formatPrice(order.total)}</span>
                </div>
              </div>

              {/* Items preview */}
              <div className="flex gap-2 overflow-x-auto scrollbar-hide pb-1">
                {order.bundles.map((b) => (
                  <div key={b.combo.id} className="flex-none">
                    <img src={b.combo.heroImageUrl} alt={b.combo.title} className="w-16 h-16 rounded-xl object-cover bg-neutral-100 dark:bg-neutral-800" onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }} />
                    <p className="text-[9px] text-center text-neutral-400 mt-0.5 w-16 truncate">{b.combo.title}</p>
                  </div>
                ))}
                {order.items.map((ci) => (
                  <div key={`${ci.item.id}-${ci.selectedSize}`} className="flex-none">
                    <img src={ci.item.imageUrl} alt={ci.item.name} className="w-16 h-16 rounded-xl object-cover bg-neutral-100 dark:bg-neutral-800" onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }} />
                    <p className="text-[9px] text-center text-neutral-400 mt-0.5 w-16 truncate">{ci.item.name}</p>
                  </div>
                ))}
              </div>

              <div className="flex items-center justify-between mt-3 pt-3 border-t border-neutral-100 dark:border-neutral-700 text-xs text-neutral-500">
                <span>{order.address.city}, {order.address.state}</span>
                <span className="uppercase">{order.paymentMethod}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default OrdersPage;
