import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { getComboById } from '../data/combos';
import { items as allItems } from '../data/items';
import { useCartStore } from '../store/cartStore';
import { formatPrice, getHotspotPosition } from '../utils/formatters';
import ItemDetailModal from '../components/ItemDetailModal';
import ItemCard from '../components/cards/ItemCard';
import type { Item } from '../types';
import toast from 'react-hot-toast';

const OutfitDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addBundle, addItem } = useCartStore();
  const combo = id ? getComboById(id) : null;

  const [modalItem, setModalItem] = useState<Item | null>(null);
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({});
  const [activeHotspot, setActiveHotspot] = useState<string | null>(null);

  if (!combo) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <p className="text-2xl mb-4">Outfit not found</p>
          <button onClick={() => navigate('/search')} className="btn-primary">Browse Outfits</button>
        </div>
      </div>
    );
  }

  const handleBuyFullOutfit = () => {
    addBundle(combo, selectedSizes);
    toast.success(`${combo.title} added to cart! 🛍`, {
      style: { background: '#BBFF00', color: '#1A2E00', fontWeight: 600 },
    });
    navigate('/cart');
  };

  const handleAddSingleItem = (item: Item) => {
    const size = selectedSizes[item.id];
    const needsSize = !(item.sizes.length === 1 && item.sizes[0] === 'One Size');
    if (needsSize && !size) {
      toast.error(`Please select a size for ${item.name}`);
      setModalItem(item);
      return;
    }
    addItem(item, size || 'One Size', item.colors[0] || '');
    toast.success(`${item.name} added!`, { icon: '✓' });
  };

  const savingsAmount = combo.totalBeforeDiscount - combo.totalAfterDiscount;

  // Suggest matching items not in combo
  const pairedItems = allItems
    .filter((i) => !combo.items.find((ci) => ci.id === i.id))
    .filter((i) => i.styleTags.some((t) => combo.items[0].styleTags.includes(t)))
    .slice(0, 4);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button onClick={() => navigate(-1)} className="flex items-center gap-2 text-sm text-neutral-500 hover:text-neutral-700 dark:hover:text-neutral-300 mb-6 transition-colors">
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg>
        Back
      </button>

      <div className="grid lg:grid-cols-2 gap-8 xl:gap-12">
        {/* Left: Image with hotspots */}
        <div className="relative">
          <div className="relative aspect-[3/4] rounded-3xl overflow-hidden bg-neutral-100 dark:bg-neutral-800">
            <img
              src={combo.heroImageUrl}
              alt={combo.title}
              className="w-full h-full object-cover"
              onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }}
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />

            {/* Hotspot buttons */}
            {combo.items.map((item) => {
              const pos = getHotspotPosition(item.category);
              return (
                <button
                  key={item.id}
                  aria-label={`View ${item.name}`}
                  onClick={() => { setActiveHotspot(item.id); setModalItem(item); }}
                  style={{ left: `${pos.x}%`, top: `${pos.y}%` }}
                  className="absolute -translate-x-1/2 -translate-y-1/2 group"
                >
                  <motion.div
                    animate={{ scale: [1, 1.2, 1] }}
                    transition={{ repeat: Infinity, duration: 2, delay: Math.random() }}
                    className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all ${
                      activeHotspot === item.id
                        ? 'bg-accent border-accent text-accent-fg'
                        : 'bg-white/90 border-white'
                    }`}
                  >
                    <svg className="w-3 h-3 text-neutral-900" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 5v14M5 12h14" />
                    </svg>
                  </motion.div>
                  {/* Tooltip */}
                  <div className="absolute left-10 top-1/2 -translate-y-1/2 bg-white dark:bg-neutral-800 text-xs font-medium px-2.5 py-1.5 rounded-xl shadow-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 border border-black/5 dark:border-white/10">
                    {item.name}
                    <br />
                    <span className="font-bold text-accent">{formatPrice(item.price)}</span>
                  </div>
                </button>
              );
            })}
          </div>

          <p className="text-xs text-neutral-500 text-center mt-3">
            👆 Tap the + dots to see individual items
          </p>
        </div>

        {/* Right: Details */}
        <div className="flex flex-col gap-6">
          {/* Header */}
          <div>
            <div className="flex flex-wrap gap-2 mb-3">
              {combo.tags.map((tag) => (
                <span key={tag} className="text-[10px] px-2.5 py-1 rounded-full bg-accent/10 text-accent-fg dark:text-accent font-semibold uppercase tracking-wide capitalize">
                  {tag}
                </span>
              ))}
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-light mb-2">{combo.title}</h1>
            <p className="text-neutral-500 dark:text-neutral-400">{combo.description}</p>
          </div>

          {/* Price */}
          <div className="flex items-end gap-3">
            <span className="text-4xl font-bold">{formatPrice(combo.totalAfterDiscount)}</span>
            <span className="text-lg text-neutral-400 line-through mb-1">{formatPrice(combo.totalBeforeDiscount)}</span>
            <span className="mb-1 text-sm font-semibold text-green-500">
              Save {formatPrice(savingsAmount)} ({combo.discountPercent}% off)
            </span>
          </div>

          {/* Items breakdown */}
          <div>
            <h3 className="font-semibold text-sm uppercase tracking-wider mb-3">What's included</h3>
            <div className="space-y-3">
              {combo.items.map((item) => (
                <div
                  key={item.id}
                  className={`flex items-center gap-3 p-3 rounded-2xl border transition-all cursor-pointer ${
                    activeHotspot === item.id
                      ? 'border-accent bg-accent/5'
                      : 'border-neutral-100 dark:border-neutral-700 hover:border-neutral-300 dark:hover:border-neutral-600'
                  }`}
                  onClick={() => { setActiveHotspot(item.id); setModalItem(item); }}
                >
                  <img
                    src={item.imageUrl}
                    alt={item.altText}
                    className="w-14 h-14 rounded-xl object-cover bg-neutral-100 dark:bg-neutral-800"
                    onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0.3'; }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium leading-tight truncate">{item.name}</p>
                    <p className="text-xs text-neutral-500 dark:text-neutral-400 capitalize">{item.category}</p>
                    {selectedSizes[item.id] && (
                      <span className="text-[10px] bg-accent/10 text-accent-fg dark:text-accent px-2 py-0.5 rounded-full font-medium">
                        Size: {selectedSizes[item.id]}
                      </span>
                    )}
                  </div>
                  <span className="font-semibold text-sm shrink-0">{formatPrice(item.price)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* CTAs */}
          <div className="flex flex-col gap-3 sticky bottom-20 md:bottom-0 md:relative bg-bg-light dark:bg-bg-dark py-4 md:py-0 -mx-4 px-4 md:mx-0 md:px-0">
            <button onClick={handleBuyFullOutfit} className="btn-primary w-full text-base py-4">
              Buy Full Outfit — {formatPrice(combo.totalAfterDiscount)}
              <span className="text-[10px] ml-2 opacity-70 font-normal">{combo.discountPercent}% saved</span>
            </button>
            <div className="grid grid-cols-2 gap-3">
              {combo.items.slice(0, 2).map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleAddSingleItem(item)}
                  className="btn-outline text-xs py-2"
                >
                  + {item.category}
                </button>
              ))}
            </div>
          </div>

          <p className="text-[11px] text-neutral-500 flex items-center gap-2">
            <svg className="w-3.5 h-3.5 text-green-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
            Free delivery · Easy 7-day returns · Secure checkout
          </p>
        </div>
      </div>

      {/* Complete the look */}
      {pairedItems.length > 0 && (
        <section className="mt-16">
          <div className="mb-6">
            <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">Build on this</p>
            <h2 className="font-display text-3xl font-light">Complete the Look</h2>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {pairedItems.map((item) => (
              <ItemCard key={item.id} item={item} onOpenModal={setModalItem} />
            ))}
          </div>
        </section>
      )}

      <ItemDetailModal
        item={modalItem}
        isOpen={!!modalItem}
        onClose={() => { setModalItem(null); setActiveHotspot(null); }}
      />
    </div>
  );
};

export default OutfitDetailPage;
