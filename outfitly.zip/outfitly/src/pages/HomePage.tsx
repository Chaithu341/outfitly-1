import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { trendingCombos } from '../data/combos';
import { items } from '../data/items';
import { formatPrice } from '../utils/formatters';
import OutfitCard from '../components/cards/OutfitCard';
import ItemCard from '../components/cards/ItemCard';
import ItemDetailModal from '../components/ItemDetailModal';
import type { Item } from '../types';

const BUDGET_CHIPS = [199, 299, 399, 499];

const HERO_IMAGES = [
  {
    src: 'https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=700&q=80',
    label: 'Girls Collection',
    tag: 'New Arrivals',
    link: '/search?gender=girls',
  },
  {
    src: 'https://images.unsplash.com/photo-1552374196-1ab2a1c593e8?auto=format&fit=crop&w=700&q=80',
    label: 'Boys Collection',
    tag: 'Trending Now',
    link: '/search?gender=boys',
  },
];

const CATEGORY_TILES = [
  {
    label: 'Boys',
    sub: 'Street to prep',
    link: '/search?gender=boys',
    img: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=500&q=80',
  },
  {
    label: 'Girls',
    sub: 'Soft to bold',
    link: '/search?gender=girls',
    img: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e0?auto=format&fit=crop&w=500&q=80',
  },
  {
    label: 'Y2K Vibes',
    sub: 'All genders',
    link: '/search?style=y2k',
    img: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=500&q=80',
  },
  {
    label: 'Minimal',
    sub: 'Clean looks',
    link: '/search?style=minimal',
    img: 'https://images.unsplash.com/photo-1551488831-00ddcb6c6bd3?auto=format&fit=crop&w=500&q=80',
  },
];

const newArrivals = items.filter((i) => i.isNew).slice(0, 8);
const trendingItems = [...items].sort((a, b) => b.trendingScore - a.trendingScore).slice(0, 8);

const HomePage: React.FC = () => {
  const navigate = useNavigate();
  const [modalItem, setModalItem] = useState<Item | null>(null);
  const [heroIdx, setHeroIdx] = useState(0);

  return (
    <div className="overflow-x-hidden">
      {/* ── HERO ─────────────────────────────────────────────────────── */}
      <section className="relative min-h-[80vh] md:min-h-screen flex items-end overflow-hidden bg-neutral-900">
        <div className="absolute inset-0 flex">
          {HERO_IMAGES.map((h, i) => (
            <div key={i} className="flex-1 relative overflow-hidden">
              <img
                src={h.src}
                alt={h.label}
                className="absolute inset-0 w-full h-full object-cover object-top"
                onError={(e) => { (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=700&q=80'; }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-transparent" />
            </div>
          ))}
        </div>

        <div className="relative z-10 w-full px-6 pb-16 md:pb-20 text-white">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="max-w-7xl mx-auto"
          >
            <p className="text-xs uppercase tracking-[0.3em] text-accent mb-3 font-semibold">
              SS '24 Collection
            </p>
            <h1 className="font-display text-5xl md:text-7xl lg:text-8xl font-light italic leading-none mb-4">
              Dress Like<br />
              <em className="not-italic font-semibold text-accent">You Mean It</em>
            </h1>
            <p className="text-sm md:text-base text-neutral-300 mb-8 max-w-md">
              Complete outfits under ₹500. No overthinking. Just your style.
            </p>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={() => navigate('/search?tab=combos')}
                className="btn-primary text-sm"
              >
                Shop Outfits
              </button>
              <button
                onClick={() => navigate('/search?tab=singles')}
                className="btn-outline border-white/40 text-white hover:bg-white/10 text-sm"
              >
                Browse Singles
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── BUDGET CHIPS ─────────────────────────────────────────────── */}
      <section className="py-8 px-4">
        <div className="max-w-7xl mx-auto">
          <p className="text-xs uppercase tracking-widest text-neutral-500 dark:text-neutral-400 mb-4 text-center font-semibold">
            Shop by Budget
          </p>
          <div className="flex flex-wrap justify-center gap-3">
            {BUDGET_CHIPS.map((budget) => (
              <button
                key={budget}
                onClick={() => navigate(`/search?budget=${budget}`)}
                className="flex flex-col items-center px-6 py-3 rounded-2xl border border-neutral-200 dark:border-neutral-700 hover:border-accent hover:bg-accent/5 dark:hover:bg-accent/5 transition-all group"
              >
                <span className="text-lg font-bold group-hover:text-accent transition-colors">
                  {formatPrice(budget)}
                </span>
                <span className="text-[10px] text-neutral-500 dark:text-neutral-400 uppercase tracking-wide">
                  Under
                </span>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── TRENDING OUTFIT COMBOS ───────────────────────────────────── */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-6">
            <div>
              <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">
                Outfit Sets
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-light">
                Trending Right Now
              </h2>
            </div>
            <button
              onClick={() => navigate('/search?tab=combos')}
              className="text-sm text-accent font-semibold hover:underline underline-offset-2"
            >
              View all →
            </button>
          </div>

          {/* Mobile: horizontal scroll */}
          <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide -mx-4 px-4 pb-4">
            {trendingCombos.map((combo) => (
              <div key={combo.id} className="snap-start flex-none w-64 sm:w-72">
                <OutfitCard combo={combo} compact />
              </div>
            ))}
          </div>

          {/* Desktop: grid */}
          <div className="hidden lg:grid grid-cols-3 xl:grid-cols-4 gap-5 mt-6">
            {trendingCombos.slice(0, 4).map((combo) => (
              <OutfitCard key={combo.id} combo={combo} />
            ))}
          </div>
        </div>
      </section>

      {/* ── CATEGORY TILES ───────────────────────────────────────────── */}
      <section className="py-12 px-4 bg-neutral-50 dark:bg-neutral-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-8">
            <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-2">
              Discover
            </p>
            <h2 className="font-display text-3xl md:text-4xl font-light">
              Shop Your Aesthetic
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {CATEGORY_TILES.map((tile) => (
              <motion.button
                key={tile.label}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => navigate(tile.link)}
                className="relative aspect-[3/4] rounded-2xl overflow-hidden group text-left"
              >
                <img
                  src={tile.img}
                  alt={tile.label}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <p className="font-semibold text-white text-lg leading-tight">{tile.label}</p>
                  <p className="text-xs text-neutral-300">{tile.sub}</p>
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* ── NEW ARRIVALS ─────────────────────────────────────────────── */}
      <section className="py-12 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-6">
            <div>
              <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">
                Fresh Drops
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-light">
                New Arrivals
              </h2>
            </div>
            <button
              onClick={() => navigate('/search?sort=new')}
              className="text-sm text-accent font-semibold hover:underline underline-offset-2"
            >
              See all →
            </button>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-4">
            {newArrivals.map((item) => (
              <ItemCard key={item.id} item={item} onOpenModal={setModalItem} />
            ))}
          </div>
        </div>
      </section>

      {/* ── TRENDING SINGLES ─────────────────────────────────────────── */}
      <section className="py-12 px-4 bg-neutral-50 dark:bg-neutral-900/50">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-end justify-between mb-6">
            <div>
              <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">
                Most Loved
              </p>
              <h2 className="font-display text-3xl md:text-4xl font-light">
                Best Sellers
              </h2>
            </div>
            <button
              onClick={() => navigate('/search?sort=trending')}
              className="text-sm text-accent font-semibold hover:underline underline-offset-2"
            >
              View all →
            </button>
          </div>
          <div className="flex gap-4 overflow-x-auto snap-x snap-mandatory scrollbar-hide -mx-4 px-4 pb-4 lg:grid lg:grid-cols-4 lg:overflow-visible lg:gap-5">
            {trendingItems.map((item) => (
              <div key={item.id} className="snap-start flex-none w-48 sm:w-56 lg:w-auto">
                <ItemCard item={item} onOpenModal={setModalItem} />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── COMPLETE THE LOOK CTA ────────────────────────────────────── */}
      <section className="py-16 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="relative rounded-3xl overflow-hidden bg-neutral-900 min-h-[300px] flex items-center">
            <img
              src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1400&q=80"
              alt="Complete the look"
              className="absolute inset-0 w-full h-full object-cover opacity-50"
              onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0'; }}
            />
            <div className="relative z-10 p-8 md:p-16 max-w-lg">
              <p className="text-xs uppercase tracking-[0.3em] text-accent mb-3 font-semibold">
                Build Your Fit
              </p>
              <h2 className="font-display text-4xl md:text-5xl text-white font-light italic mb-4 leading-tight">
                Complete the Look — ₹0 Styling Fee
              </h2>
              <p className="text-sm text-neutral-300 mb-8">
                Mix and match tops, bottoms, shoes and accessories. Every piece under ₹500.
              </p>
              <div className="flex flex-wrap gap-3">
                {(['Boys', 'Girls', 'Unisex'] as const).map((g) => (
                  <button
                    key={g}
                    onClick={() => navigate(`/search?tab=combos&gender=${g.toLowerCase()}`)}
                    className="btn-primary text-sm"
                  >
                    {g} Outfits
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Item detail modal */}
      <ItemDetailModal
        item={modalItem}
        isOpen={!!modalItem}
        onClose={() => setModalItem(null)}
      />
    </div>
  );
};

export default HomePage;
