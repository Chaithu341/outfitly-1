import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { useWishlistStore } from '../store/wishlistStore';
import { useCartStore } from '../store/cartStore';
import { formatPrice, formatDate } from '../utils/formatters';
import ImageWithFallback from '../components/ui/ImageWithFallback';
import ItemDetailModal from '../components/ItemDetailModal';
import type { Item } from '../types';
import toast from 'react-hot-toast';

const WishlistPage: React.FC = () => {
  const navigate = useNavigate();
  const { items, removeItem, clearWishlist } = useWishlistStore();
  const { addItem } = useCartStore();
  const [modalItem, setModalItem] = useState<Item | null>(null);

  const handleMoveToCart = (wi: (typeof items)[0]) => {
    const item = wi.item;
    if (item.sizes.length === 1 && item.sizes[0] === 'One Size') {
      addItem(item, 'One Size', item.colors[0] || '');
      removeItem(item.id);
      toast.success(`${item.name} moved to cart!`, { icon: '🛍' });
    } else {
      setModalItem(item);
    }
  };

  if (items.length === 0) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center px-4 text-center">
        <div className="w-24 h-24 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center mb-6">
          <svg className="w-12 h-12 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
          </svg>
        </div>
        <h2 className="font-display text-3xl font-light mb-2">Your wishlist is empty</h2>
        <p className="text-neutral-500 mb-8">Save items you love and come back to them anytime.</p>
        <button onClick={() => navigate('/search')} className="btn-primary">Discover Styles</button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between mb-8">
        <div>
          <h1 className="font-display text-4xl font-light">Wishlist</h1>
          <p className="text-neutral-500 text-sm mt-1">{items.length} saved item{items.length !== 1 ? 's' : ''}</p>
        </div>
        {items.length > 0 && (
          <button
            onClick={() => { clearWishlist(); toast('Wishlist cleared', { icon: '🧹' }); }}
            className="text-sm text-neutral-500 hover:text-red-400 transition-colors"
          >
            Clear all
          </button>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
        <AnimatePresence>
          {items.map((wi) => (
            <motion.div
              key={wi.item.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="card overflow-hidden group"
            >
              <div className="relative aspect-square">
                <ImageWithFallback
                  src={wi.item.imageUrl}
                  alt={wi.item.altText}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
                <button
                  aria-label="Remove from wishlist"
                  onClick={() => { removeItem(wi.item.id); toast('Removed ❤️‍🩹', { duration: 1500 }); }}
                  className="absolute top-2 right-2 w-7 h-7 rounded-full bg-white/90 dark:bg-neutral-800/90 flex items-center justify-center hover:bg-red-50 transition-colors"
                >
                  <svg className="w-4 h-4 fill-red-400 text-red-400" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={0}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                  </svg>
                </button>
              </div>
              <div className="p-3">
                <p className="text-sm font-medium leading-tight line-clamp-2 mb-1">{wi.item.name}</p>
                <p className="text-xs text-neutral-500 dark:text-neutral-400 mb-2">{formatDate(wi.addedAt)}</p>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-sm">{formatPrice(wi.item.price)}</span>
                </div>
                <button
                  onClick={() => handleMoveToCart(wi)}
                  className="w-full btn-primary text-xs py-1.5 mt-2"
                >
                  Add to Cart
                </button>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      <ItemDetailModal item={modalItem} isOpen={!!modalItem} onClose={() => setModalItem(null)} />
    </div>
  );
};

export default WishlistPage;
