import React, { useState } from 'react';
import { useOrderStore } from '../store/orderStore';
import { formatPrice, formatDate } from '../utils/formatters';
import { exportOrdersJSON, exportOrdersCSV, copyOrderJSON } from '../utils/export';
import type { Order } from '../types';
import toast from 'react-hot-toast';

const STATUS_OPTIONS = ['placed', 'confirmed', 'shipped', 'delivered'] as const;

const AdminPage: React.FC = () => {
  const { getAllOrders, updateOrderStatus } = useOrderStore();
  const orders = getAllOrders();
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [searchQ, setSearchQ] = useState('');

  const filtered = orders.filter(
    (o) =>
      o.id.toLowerCase().includes(searchQ.toLowerCase()) ||
      o.userEmail.toLowerCase().includes(searchQ.toLowerCase()) ||
      o.userName.toLowerCase().includes(searchQ.toLowerCase())
  );

  const totalRevenue = orders.reduce((s, o) => s + o.total, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex items-end justify-between mb-8">
        <div>
          <p className="text-xs uppercase tracking-widest text-accent font-semibold mb-1">Admin</p>
          <h1 className="font-display text-4xl font-light">Orders Dashboard</h1>
        </div>
        <div className="flex gap-2">
          <button onClick={() => exportOrdersJSON(orders)} className="btn-outline text-sm py-2 px-4 flex items-center gap-1.5">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            Export JSON
          </button>
          <button onClick={() => exportOrdersCSV(orders)} className="btn-outline text-sm py-2 px-4 flex items-center gap-1.5">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            Export CSV
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        {[
          { label: 'Total Orders', value: orders.length, icon: '📦' },
          { label: 'Total Revenue', value: formatPrice(totalRevenue), icon: '💰' },
          { label: 'Pending', value: orders.filter((o) => o.status === 'placed').length, icon: '⏳' },
          { label: 'Delivered', value: orders.filter((o) => o.status === 'delivered').length, icon: '✅' },
        ].map((stat) => (
          <div key={stat.label} className="card p-5">
            <div className="text-2xl mb-2">{stat.icon}</div>
            <p className="font-bold text-2xl">{stat.value}</p>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">{stat.label}</p>
          </div>
        ))}
      </div>

      {/* Search */}
      <div className="relative mb-5">
        <input
          type="text"
          value={searchQ}
          onChange={(e) => setSearchQ(e.target.value)}
          placeholder="Search by order ID, customer name or email…"
          className="input-field pl-10"
        />
        <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
      </div>

      {orders.length === 0 ? (
        <div className="text-center py-20">
          <p className="text-neutral-500">No orders yet. Place an order first to see it here.</p>
        </div>
      ) : (
        <div className="flex gap-6">
          {/* Orders table */}
          <div className="flex-1 overflow-hidden">
            <div className="card overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-neutral-100 dark:border-neutral-700">
                    <th className="text-left p-4 font-semibold text-xs uppercase tracking-wider text-neutral-500">Order</th>
                    <th className="text-left p-4 font-semibold text-xs uppercase tracking-wider text-neutral-500">Customer</th>
                    <th className="text-left p-4 font-semibold text-xs uppercase tracking-wider text-neutral-500 hidden sm:table-cell">Date</th>
                    <th className="text-left p-4 font-semibold text-xs uppercase tracking-wider text-neutral-500">Total</th>
                    <th className="text-left p-4 font-semibold text-xs uppercase tracking-wider text-neutral-500">Status</th>
                    <th className="p-4" />
                  </tr>
                </thead>
                <tbody>
                  {filtered.map((order) => (
                    <tr
                      key={order.id}
                      className={`border-b border-neutral-50 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 cursor-pointer transition-colors ${selectedOrder?.id === order.id ? 'bg-accent/5' : ''}`}
                      onClick={() => setSelectedOrder(selectedOrder?.id === order.id ? null : order)}
                    >
                      <td className="p-4">
                        <p className="font-mono text-xs text-neutral-500">{order.id}</p>
                      </td>
                      <td className="p-4">
                        <p className="font-medium">{order.userName}</p>
                        <p className="text-xs text-neutral-400">{order.userEmail}</p>
                      </td>
                      <td className="p-4 hidden sm:table-cell text-neutral-500">{formatDate(order.createdAt)}</td>
                      <td className="p-4 font-bold">{formatPrice(order.total)}</td>
                      <td className="p-4">
                        <select
                          value={order.status}
                          onChange={(e) => {
                            e.stopPropagation();
                            updateOrderStatus(order.id, e.target.value as Order['status']);
                            toast.success(`Status updated to ${e.target.value}`);
                          }}
                          onClick={(e) => e.stopPropagation()}
                          className="text-xs border border-neutral-200 dark:border-neutral-700 rounded-lg px-2 py-1 bg-white dark:bg-neutral-800 capitalize"
                        >
                          {STATUS_OPTIONS.map((s) => (
                            <option key={s} value={s}>{s}</option>
                          ))}
                        </select>
                      </td>
                      <td className="p-4">
                        <button
                          aria-label="Copy order JSON"
                          onClick={async (e) => {
                            e.stopPropagation();
                            const ok = await copyOrderJSON(order);
                            toast(ok ? 'Copied!' : 'Copy failed', { icon: ok ? '📋' : '❌', duration: 1500 });
                          }}
                          className="text-neutral-400 hover:text-accent transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Order detail drawer */}
          {selectedOrder && (
            <div className="w-72 xl:w-80 shrink-0">
              <div className="card p-5 sticky top-20">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="font-semibold">Order Details</h3>
                  <button onClick={() => setSelectedOrder(null)} className="text-neutral-400 hover:text-neutral-600">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
                <div className="space-y-3 text-sm">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-neutral-500 mb-0.5">Order ID</p>
                    <p className="font-mono text-xs">{selectedOrder.id}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-neutral-500 mb-0.5">Customer</p>
                    <p className="font-medium">{selectedOrder.userName}</p>
                    <p className="text-xs text-neutral-500">{selectedOrder.userEmail}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-neutral-500 mb-0.5">Address</p>
                    <p className="text-xs">{selectedOrder.address.fullName}</p>
                    <p className="text-xs text-neutral-500">{selectedOrder.address.line1}</p>
                    <p className="text-xs text-neutral-500">{selectedOrder.address.city}, {selectedOrder.address.state} {selectedOrder.address.pincode}</p>
                    <p className="text-xs text-neutral-500">📞 {selectedOrder.address.phone}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-neutral-500 mb-1">Items</p>
                    {selectedOrder.bundles.map((b) => (
                      <p key={b.combo.id} className="text-xs">• {b.combo.title} (bundle) ×{b.quantity} — {formatPrice(b.combo.totalAfterDiscount * b.quantity)}</p>
                    ))}
                    {selectedOrder.items.map((ci) => (
                      <p key={`${ci.item.id}-${ci.selectedSize}`} className="text-xs">• {ci.item.name} ({ci.selectedSize}) ×{ci.quantity} — {formatPrice(ci.item.price * ci.quantity)}</p>
                    ))}
                  </div>
                  <div className="pt-2 border-t border-neutral-100 dark:border-neutral-700">
                    <div className="flex justify-between">
                      <span className="text-neutral-500">Total</span>
                      <span className="font-bold">{formatPrice(selectedOrder.total)}</span>
                    </div>
                    <div className="flex justify-between text-xs text-neutral-400 mt-0.5">
                      <span>Payment</span>
                      <span className="uppercase">{selectedOrder.paymentMethod}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default AdminPage;
